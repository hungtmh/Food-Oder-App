@echo off
echo ========================================
echo   BUILD - Login Demo (23127195)
echo ========================================

REM Tao thu muc bin neu chua co
if not exist bin mkdir bin

REM Compile tat ca file Java
echo Compiling Java files...
javac -encoding UTF-8 -cp "lib/*" -d bin src\dto\*.java src\dao\*.java src\bus\*.java src\gui\*.java

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ❌ Build FAILED!
    pause
    exit /b 1
)

REM Copy resources vao bin
echo Copying resources...
if not exist bin\resources mkdir bin\resources
copy resources\config.properties bin\resources\ >nul 2>&1
copy resources\config.properties bin\ >nul 2>&1

echo.
echo ✅ Build SUCCESS!
echo.
echo Output: bin/
echo.
pause
