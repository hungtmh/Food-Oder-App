# Bài tập cá nhân - Chức năng Đăng nhập (Login)

## Thông tin sinh viên
- **Mã số sinh viên:** 23127195
- **Chức năng demo:** Đăng nhập (Login Feature)

---

## 1. Mô tả chức năng

Chức năng **Đăng nhập (Login)** cho phép người dùng:
- Nhập tên đăng nhập hoặc email
- Nhập mật khẩu
- Xác thực thông tin và đăng nhập vào hệ thống
- Hiển thị thông báo lỗi nếu đăng nhập thất bại
- Chuyển đến màn hình chính sau khi đăng nhập thành công

---

## 2. Kiến trúc 3 Layer

```
┌─────────────────────────────────────────────────────────────┐
│                    GUI LAYER (Presentation)                  │
│  ┌─────────────────┐     ┌─────────────────┐                │
│  │  LoginFrame.java │     │  MainFrame.java  │                │
│  └────────┬────────┘     └─────────────────┘                │
│           │                                                  │
└───────────┼──────────────────────────────────────────────────┘
            │
            ▼
┌─────────────────────────────────────────────────────────────┐
│                 BUS LAYER (Business Logic)                   │
│  ┌─────────────────┐                                        │
│  │  LoginBUS.java   │  - Xác thực đăng nhập                  │
│  └────────┬────────┘  - Hash/verify password                │
│           │           - Validation dữ liệu                  │
└───────────┼──────────────────────────────────────────────────┘
            │
            ▼
┌─────────────────────────────────────────────────────────────┐
│                  DAO LAYER (Data Access)                     │
│  ┌────────────────────────┐  ┌─────────────────────────┐    │
│  │ DatabaseConnection.java │  │      UserDAO.java        │    │
│  └────────────────────────┘  └─────────────────────────┘    │
│           │                            │                    │
└───────────┼────────────────────────────┼────────────────────┘
            │                            │
            ▼                            ▼
┌─────────────────────────────────────────────────────────────┐
│                       DATABASE (MySQL)                       │
│       ┌─────────┐              ┌─────────────────┐          │
│       │  users  │              │  login_history  │          │
│       └─────────┘              └─────────────────┘          │
└─────────────────────────────────────────────────────────────┘
```

---

## 3. Danh sách các Class và Method

### 3.1 GUI Layer (`src/gui/`)

#### LoginFrame.java
| Method | Mô tả |
|--------|-------|
| `LoginFrame()` | Constructor - Khởi tạo giao diện |
| `initializeComponents()` | Khởi tạo các thành phần UI |
| `setupLayout()` | Thiết lập layout GridBagLayout |
| `applyModernStyle()` | Áp dụng style hiện đại |
| `handleLogin()` | Xử lý sự kiện đăng nhập |
| `handleRegister()` | Xử lý sự kiện đăng ký |
| `setLoading(boolean)` | Hiển thị/ẩn trạng thái loading |
| `showError(String)` | Hiển thị thông báo lỗi |
| `showSuccess(String)` | Hiển thị thông báo thành công |
| `createStyledTextField(String)` | Tạo TextField với placeholder |
| `createStyledPasswordField(String)` | Tạo PasswordField với placeholder |
| `createPrimaryButton(String)` | Tạo button chính |
| `createSecondaryButton(String)` | Tạo button phụ |

#### MainFrame.java
| Method | Mô tả |
|--------|-------|
| `MainFrame(UserDTO)` | Constructor với thông tin user |
| `initializeComponents()` | Khởi tạo giao diện chính |
| `createHeaderPanel()` | Tạo panel header |
| `createContentPanel()` | Tạo panel nội dung |
| `createUserInfoCard()` | Tạo card thông tin user |
| `handleLogout()` | Xử lý đăng xuất |

### 3.2 BUS Layer (`src/bus/`)

#### LoginBUS.java
| Method | Mô tả |
|--------|-------|
| `LoginBUS()` | Constructor - Khởi tạo UserDAO |
| `login(String, String)` | Xử lý logic đăng nhập |
| `hashPassword(String)` | Hash mật khẩu bằng SHA-256 |
| `verifyPassword(String, String)` | Xác thực mật khẩu |
| `isUsernameExists(String)` | Kiểm tra username tồn tại |
| `isEmailExists(String)` | Kiểm tra email tồn tại |
| `getUserByUsername(String)` | Lấy thông tin user |

### 3.3 DAO Layer (`src/dao/`)

#### DatabaseConnection.java
| Method | Mô tả |
|--------|-------|
| `getInstance()` | Lấy instance Singleton |
| `getConnection()` | Tạo kết nối database |
| `closeConnection(Connection)` | Đóng kết nối |
| `loadConfig()` | Đọc cấu hình từ file |

#### UserDAO.java
| Method | Mô tả |
|--------|-------|
| `UserDAO()` | Constructor |
| `findByUsernameOrEmail(String)` | Tìm user theo username/email |
| `findById(int)` | Tìm user theo ID |
| `findAll()` | Lấy tất cả users |
| `isUsernameExists(String)` | Kiểm tra username tồn tại |
| `isEmailExists(String)` | Kiểm tra email tồn tại |
| `insert(UserDTO)` | Thêm user mới |
| `update(UserDTO)` | Cập nhật user |
| `delete(int)` | Xóa user |
| `logLoginHistory(int)` | Ghi lịch sử đăng nhập |
| `updatePassword(int, String)` | Cập nhật mật khẩu |

### 3.4 DTO Layer (`src/dto/`)

#### UserDTO.java
| Field | Mô tả |
|-------|-------|
| `id` | ID của user |
| `username` | Tên đăng nhập |
| `password` | Mật khẩu (đã hash) |
| `fullName` | Họ tên đầy đủ |
| `email` | Email |
| `address` | Địa chỉ |
| `birthDate` | Ngày sinh |
| `gender` | Giới tính |
| `status` | Trạng thái (active/locked) |
| `createdAt` | Thời điểm tạo |

#### LoginResultDTO.java
| Field/Method | Mô tả |
|--------------|-------|
| `success` | Kết quả đăng nhập |
| `message` | Thông báo |
| `user` | Thông tin user |
| `success(UserDTO)` | Factory: tạo kết quả thành công |
| `failure(String)` | Factory: tạo kết quả thất bại |

---

## 4. Công nghệ sử dụng

| Công nghệ | Mô tả |
|-----------|-------|
| **Java Swing** | Xây dựng giao diện người dùng |
| **JDBC** | Kết nối và thao tác với MySQL |
| **MySQL** | Cơ sở dữ liệu |
| **SHA-256** | Mã hóa mật khẩu |

---

## 5. Cấu trúc thư mục

```
23127195/
├── src/
│   ├── gui/
│   │   ├── LoginFrame.java      # Giao diện đăng nhập
│   │   └── MainFrame.java       # Giao diện chính
│   ├── bus/
│   │   └── LoginBUS.java        # Business logic đăng nhập
│   ├── dao/
│   │   ├── DatabaseConnection.java  # Kết nối database
│   │   └── UserDAO.java         # Data access cho User
│   └── dto/
│       ├── UserDTO.java         # Data transfer object
│       └── LoginResultDTO.java  # Kết quả đăng nhập
├── resources/
│   ├── config.properties        # Cấu hình database
│   ├── create_database.sql      # Script tạo database
│   └── sample_data.sql          # Dữ liệu mẫu
├── lib/
│   └── mysql-connector-java-8.0.30.jar
├── screenshots/
│   ├── login_screen.png
│   ├── login_success.png
│   ├── login_error.png
│   └── main_screen.png
├── build.bat                    # Script build (Windows)
├── run.bat                      # Script chạy (Windows)
└── README.md                    # File này
```

---

## 6. Hướng dẫn cài đặt và chạy

### 6.1 Yêu cầu
- JDK 8 trở lên
- MySQL Server 5.7+ hoặc 8.0+
- MySQL Connector/J (có trong thư mục lib/)

### 6.2 Cài đặt Database

```bash
# 1. Đăng nhập MySQL
mysql -u root -p

# 2. Tạo database và bảng
source resources/create_database.sql

# 3. Thêm dữ liệu mẫu
source resources/sample_data.sql
```

### 6.3 Cấu hình

Chỉnh sửa file `resources/config.properties`:
```properties
db.url=jdbc:mysql://localhost:3306/chat_system
db.username=root
db.password=your_password
```

### 6.4 Build và chạy

**Windows:**
```batch
# Build
build.bat

# Chạy
run.bat

# Hoặc chạy JAR trực tiếp
java -jar LoginDemo.jar
```

**Manual:**
```batch
# Compile
javac -cp "lib/*" -d bin src/dao/*.java src/dto/*.java src/bus/*.java src/gui/*.java

# Run
java -cp "bin;lib/*;resources" gui.LoginFrame
```

---

## 7. Tài khoản test

| Username | Password | Trạng thái |
|----------|----------|------------|
| user1 | 123456 | Active |
| user2 | 123456 | Active |
| user3 | 123456 | Active |
| admin | 123456 | Active |
| demo | 123456 | Active |
| locked_user | 123456 | Locked |

---

## 8. Screenshots

### 8.1 Màn hình đăng nhập
![Login Screen](screenshots/login_screen.png)

### 8.2 Đăng nhập thành công
![Login Success](screenshots/login_success.png)

### 8.3 Đăng nhập thất bại
![Login Error](screenshots/login_error.png)

### 8.4 Màn hình chính
![Main Screen](screenshots/main_screen.png)

---

## 9. Điểm nổi bật

### Swing (3 điểm)
- ✅ Giao diện hiện đại với placeholder text
- ✅ Hiệu ứng hover trên buttons
- ✅ Xử lý async với SwingWorker (không block UI)
- ✅ Validation và thông báo lỗi trực quan
- ✅ Responsive layout với GridBagLayout

### JDBC (4 điểm)
- ✅ Kết nối MySQL sử dụng JDBC Driver
- ✅ PreparedStatement chống SQL Injection
- ✅ Connection pooling (Singleton pattern)
- ✅ Xử lý exception và đóng resources đúng cách
- ✅ Ghi lịch sử đăng nhập vào database

### 3-Layer Architecture (3 điểm)
- ✅ **GUI Layer:** LoginFrame, MainFrame
- ✅ **BUS Layer:** LoginBUS (business logic)
- ✅ **DAO Layer:** UserDAO, DatabaseConnection
- ✅ **DTO:** UserDTO, LoginResultDTO
- ✅ Tách biệt rõ ràng giữa các layer

---

## 10. Tác giả

- **MSSV:** 23127195
- **Môn học:** Java Programming
- **Năm học:** 2024-2025

---

*© 2024 - Bài tập cá nhân Java Swing + JDBC + 3-Layer Architecture*
