package dto;

import java.sql.Date;
import java.sql.Timestamp;

/**
 * Data Transfer Object (DTO) - User Entity
 * Đối tượng chứa dữ liệu User, dùng để truyền dữ liệu giữa các layer
 * 
 * @author 23127195
 */
public class UserDTO {
    
    private int id;
    private String username;
    private String password;
    private String fullName;
    private String email;
    private String address;
    private Date birthDate;
    private String gender;
    private String status;          // active, locked
    private Timestamp createdAt;
    
    // ========================================
    // CONSTRUCTORS
    // ========================================
    
    public UserDTO() {
        // Default constructor
    }
    
    public UserDTO(String username, String password, String fullName, String email) {
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.email = email;
        this.status = "active";
    }
    
    public UserDTO(int id, String username, String fullName, String email, String status) {
        this.id = id;
        this.username = username;
        this.fullName = fullName;
        this.email = email;
        this.status = status;
    }
    
    // ========================================
    // GETTERS & SETTERS
    // ========================================
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getFullName() {
        return fullName;
    }
    
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getAddress() {
        return address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public Date getBirthDate() {
        return birthDate;
    }
    
    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }
    
    public String getGender() {
        return gender;
    }
    
    public void setGender(String gender) {
        this.gender = gender;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    // ========================================
    // UTILITY METHODS
    // ========================================
    
    /**
     * Kiểm tra tài khoản có bị khóa không
     */
    public boolean isLocked() {
        return "locked".equals(this.status);
    }
    
    /**
     * Kiểm tra tài khoản có active không
     */
    public boolean isActive() {
        return "active".equals(this.status);
    }
    
    @Override
    public String toString() {
        return "UserDTO{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", fullName='" + fullName + '\'' +
                ", email='" + email + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
