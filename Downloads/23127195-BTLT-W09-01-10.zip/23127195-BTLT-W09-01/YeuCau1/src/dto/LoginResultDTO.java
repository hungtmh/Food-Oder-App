package dto;

/**
 * Data Transfer Object - Kết quả đăng nhập
 * Chứa thông tin trả về sau khi đăng nhập
 * 
 * @author 23127195
 */
public class LoginResultDTO {
    
    private boolean success;
    private String message;
    private UserDTO user;
    
    // ========================================
    // CONSTRUCTORS
    // ========================================
    
    public LoginResultDTO() {
        this.success = false;
        this.message = "";
        this.user = null;
    }
    
    public LoginResultDTO(boolean success, String message) {
        this.success = success;
        this.message = message;
        this.user = null;
    }
    
    public LoginResultDTO(boolean success, String message, UserDTO user) {
        this.success = success;
        this.message = message;
        this.user = user;
    }
    
    // ========================================
    // STATIC FACTORY METHODS
    // ========================================
    
    /**
     * Tạo kết quả đăng nhập thành công
     */
    public static LoginResultDTO success(UserDTO user) {
        return new LoginResultDTO(true, "Đăng nhập thành công!", user);
    }
    
    /**
     * Tạo kết quả đăng nhập thất bại
     */
    public static LoginResultDTO failure(String message) {
        return new LoginResultDTO(false, message, null);
    }
    
    /**
     * Tạo kết quả lỗi kết nối
     */
    public static LoginResultDTO connectionError() {
        return new LoginResultDTO(false, "Không thể kết nối đến database!", null);
    }
    
    /**
     * Tạo kết quả tài khoản bị khóa
     */
    public static LoginResultDTO accountLocked() {
        return new LoginResultDTO(false, "Tài khoản của bạn đã bị khóa. Vui lòng liên hệ admin!", null);
    }
    
    /**
     * Tạo kết quả sai mật khẩu
     */
    public static LoginResultDTO wrongPassword() {
        return new LoginResultDTO(false, "Sai mật khẩu! Vui lòng thử lại.", null);
    }
    
    /**
     * Tạo kết quả không tìm thấy tài khoản
     */
    public static LoginResultDTO userNotFound() {
        return new LoginResultDTO(false, "Tài khoản không tồn tại! Vui lòng kiểm tra lại.", null);
    }
    
    // ========================================
    // GETTERS & SETTERS
    // ========================================
    
    public boolean isSuccess() {
        return success;
    }
    
    public void setSuccess(boolean success) {
        this.success = success;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public UserDTO getUser() {
        return user;
    }
    
    public void setUser(UserDTO user) {
        this.user = user;
    }
    
    @Override
    public String toString() {
        return "LoginResultDTO{" +
                "success=" + success +
                ", message='" + message + '\'' +
                ", user=" + (user != null ? user.getUsername() : "null") +
                '}';
    }
}
