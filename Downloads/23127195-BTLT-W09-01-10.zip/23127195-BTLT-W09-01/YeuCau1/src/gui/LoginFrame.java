package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import bus.LoginBUS;
import dto.LoginResultDTO;
import dto.UserDTO;

/**
 * Giao diện đăng nhập - GUI Layer
 * Layer: GUI (Presentation Layer)
 * 
 * Phong cách Modern UI với:
 * - Gradient background
 * - Rounded corners
 * - Placeholder text
 * - Hover effects
 * 
 * @author 23127195
 */
public class LoginFrame extends JFrame {
    
    // ========================================
    // CONSTANTS - UI Colors
    // ========================================
    private static final Color PRIMARY_COLOR = new Color(0, 132, 255);      // Blue
    private static final Color PRIMARY_DARK = new Color(0, 102, 204);
    private static final Color BACKGROUND_COLOR = new Color(245, 247, 250);
    private static final Color TEXT_COLOR = new Color(51, 51, 51);
    private static final Color PLACEHOLDER_COLOR = new Color(153, 153, 153);
    private static final Color SUCCESS_COLOR = new Color(76, 175, 80);
    private static final Color ERROR_COLOR = new Color(244, 67, 54);
    
    // ========================================
    // UI Components
    // ========================================
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton registerButton;
    private JLabel titleLabel;
    private JLabel welcomeLabel;
    private JLabel statusLabel;
    
    // ========================================
    // Business Logic Layer
    // ========================================
    private LoginBUS loginBUS;
    
    /**
     * Constructor - Khởi tạo giao diện
     */
    public LoginFrame() {
        System.out.println("=== LoginFrame Constructor Started ===");
        
        // Khởi tạo BUS layer
        this.loginBUS = new LoginBUS();
        
        // Khởi tạo UI
        initializeComponents();
        setupLayout();
        applyModernStyle();
        
        System.out.println("=== LoginFrame Constructor Finished ===");
    }
    
    /**
     * Khởi tạo các thành phần UI
     */
    private void initializeComponents() {
        // Frame settings
        setTitle("Đăng nhập - Chat System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(450, 600);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setBackground(BACKGROUND_COLOR);
        
        // Title Label
        titleLabel = new JLabel("Chat System", JLabel.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        titleLabel.setForeground(PRIMARY_COLOR);
        
        // Welcome Label
        welcomeLabel = new JLabel("Đăng nhập để tiếp tục", JLabel.CENTER);
        welcomeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        welcomeLabel.setForeground(TEXT_COLOR);
        
        // Status Label (for messages)
        statusLabel = new JLabel("", JLabel.CENTER);
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusLabel.setVisible(false);
        
        // Username Field với placeholder
        usernameField = createStyledTextField("Tên đăng nhập hoặc email");
        
        // Password Field với placeholder
        passwordField = createStyledPasswordField("Mật khẩu");
        
        // Login Button
        loginButton = createPrimaryButton("ĐĂNG NHẬP");
        loginButton.addActionListener(e -> handleLogin());
        
        // Register Button
        registerButton = createSecondaryButton("Đăng ký tài khoản mới");
        registerButton.addActionListener(e -> handleRegister());
        
        // Enter key listener
        KeyListener enterKeyListener = new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    handleLogin();
                }
            }
        };
        
        usernameField.addKeyListener(enterKeyListener);
        passwordField.addKeyListener(enterKeyListener);
    }
    
    /**
     * Thiết lập layout
     */
    private void setupLayout() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 40, 10, 40);
        
        // Logo/Icon placeholder
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(30, 40, 5, 40);
        JLabel iconLabel = new JLabel("💬", JLabel.CENTER);
        iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 64));
        add(iconLabel, gbc);
        
        // Title
        gbc.gridy = 1;
        gbc.insets = new Insets(10, 40, 5, 40);
        add(titleLabel, gbc);
        
        // Welcome text
        gbc.gridy = 2;
        gbc.insets = new Insets(0, 40, 20, 40);
        add(welcomeLabel, gbc);
        
        // Status label
        gbc.gridy = 3;
        gbc.insets = new Insets(0, 40, 10, 40);
        add(statusLabel, gbc);
        
        // Username field
        gbc.gridy = 4;
        gbc.insets = new Insets(10, 40, 10, 40);
        add(usernameField, gbc);
        
        // Password field
        gbc.gridy = 5;
        add(passwordField, gbc);
        
        // Login button
        gbc.gridy = 6;
        gbc.insets = new Insets(20, 40, 15, 40);
        add(loginButton, gbc);
        
        // Divider
        gbc.gridy = 7;
        gbc.insets = new Insets(10, 40, 10, 40);
        add(createDividerPanel(), gbc);
        
        // Register button
        gbc.gridy = 8;
        gbc.insets = new Insets(10, 40, 40, 40);
        add(registerButton, gbc);
    }
    
    /**
     * Áp dụng style hiện đại
     */
    private void applyModernStyle() {
        // Hover effects cho buttons
        addHoverEffect(loginButton, PRIMARY_COLOR, PRIMARY_DARK);
        addHoverEffect(registerButton, Color.WHITE, new Color(240, 240, 240));
    }
    
    // ========================================
    // EVENT HANDLERS
    // ========================================
    
    /**
     * Xử lý sự kiện đăng nhập
     */
    private void handleLogin() {
        String usernameOrEmail = usernameField.getText().trim();
        String password = String.valueOf(passwordField.getPassword());
        
        System.out.println("=== handleLogin() ===");
        System.out.println("   Username/Email: " + usernameOrEmail);
        
        // Kiểm tra placeholder
        if (usernameOrEmail.equals("Tên đăng nhập hoặc email") || usernameOrEmail.isEmpty()) {
            showError("Vui lòng nhập tên đăng nhập hoặc email!");
            usernameField.requestFocus();
            return;
        }
        
        if (password.equals("Mật khẩu") || password.isEmpty()) {
            showError("Vui lòng nhập mật khẩu!");
            passwordField.requestFocus();
            return;
        }
        
        // Hiển thị loading
        setLoading(true);
        
        // Xử lý đăng nhập trong background thread (tránh block UI)
        SwingWorker<LoginResultDTO, Void> worker = new SwingWorker<LoginResultDTO, Void>() {
            @Override
            protected LoginResultDTO doInBackground() throws Exception {
                // Gọi BUS layer để xử lý logic đăng nhập
                return loginBUS.login(usernameOrEmail, password);
            }
            
            @Override
            protected void done() {
                try {
                    LoginResultDTO result = get();
                    
                    if (result.isSuccess()) {
                        // Đăng nhập thành công
                        showSuccess("Đăng nhập thành công!");
                        
                        UserDTO user = result.getUser();
                        
                        // Hiển thị thông báo chào mừng
                        JOptionPane.showMessageDialog(LoginFrame.this,
                            "Chào mừng " + user.getFullName() + "!\n\n" +
                            "Username: " + user.getUsername() + "\n" +
                            "Email: " + user.getEmail(),
                            "Đăng nhập thành công",
                            JOptionPane.INFORMATION_MESSAGE);
                        
                        // Đóng LoginFrame và mở MainFrame
                        dispose();
                        openMainFrame(user);
                        
                    } else {
                        // Đăng nhập thất bại
                        showError(result.getMessage());
                        passwordField.setText("");
                        resetPasswordPlaceholder();
                    }
                    
                } catch (Exception ex) {
                    ex.printStackTrace();
                    showError("Lỗi: " + ex.getMessage());
                } finally {
                    setLoading(false);
                }
            }
        };
        
        worker.execute();
    }
    
    /**
     * Xử lý sự kiện đăng ký
     */
    private void handleRegister() {
        JOptionPane.showMessageDialog(this,
            "Chức năng đăng ký tài khoản mới.\n" +
            "(Trong phiên bản đầy đủ, sẽ mở RegisterFrame)",
            "Đăng ký",
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Mở MainFrame sau khi đăng nhập thành công
     */
    private void openMainFrame(UserDTO user) {
        SwingUtilities.invokeLater(() -> {
            MainFrame mainFrame = new MainFrame(user);
            mainFrame.setVisible(true);
        });
    }
    
    // ========================================
    // UI HELPER METHODS
    // ========================================
    
    /**
     * Hiển thị trạng thái loading
     */
    private void setLoading(boolean loading) {
        if (loading) {
            loginButton.setEnabled(false);
            loginButton.setText("Đang đăng nhập...");
        } else {
            loginButton.setEnabled(true);
            loginButton.setText("ĐĂNG NHẬP");
        }
    }
    
    /**
     * Hiển thị thông báo lỗi
     */
    private void showError(String message) {
        statusLabel.setText("❌ " + message);
        statusLabel.setForeground(ERROR_COLOR);
        statusLabel.setVisible(true);
    }
    
    /**
     * Hiển thị thông báo thành công
     */
    private void showSuccess(String message) {
        statusLabel.setText("✅ " + message);
        statusLabel.setForeground(SUCCESS_COLOR);
        statusLabel.setVisible(true);
    }
    
    /**
     * Reset placeholder cho password field
     */
    private void resetPasswordPlaceholder() {
        passwordField.setForeground(PLACEHOLDER_COLOR);
        passwordField.setEchoChar((char) 0);
        passwordField.setText("Mật khẩu");
    }
    
    /**
     * Tạo TextField với placeholder style
     */
    private JTextField createStyledTextField(String placeholder) {
        JTextField field = new JTextField(20);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setForeground(PLACEHOLDER_COLOR);
        field.setText(placeholder);
        field.setPreferredSize(new Dimension(300, 45));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 220), 1),
            BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));
        
        // Placeholder behavior
        field.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (field.getText().equals(placeholder)) {
                    field.setText("");
                    field.setForeground(TEXT_COLOR);
                }
            }
            
            @Override
            public void focusLost(FocusEvent e) {
                if (field.getText().isEmpty()) {
                    field.setForeground(PLACEHOLDER_COLOR);
                    field.setText(placeholder);
                }
            }
        });
        
        return field;
    }
    
    /**
     * Tạo PasswordField với placeholder style
     */
    private JPasswordField createStyledPasswordField(String placeholder) {
        JPasswordField field = new JPasswordField(20);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setForeground(PLACEHOLDER_COLOR);
        field.setEchoChar((char) 0); // Hiển thị text placeholder
        field.setText(placeholder);
        field.setPreferredSize(new Dimension(300, 45));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 220), 1),
            BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));
        
        // Placeholder behavior
        field.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (String.valueOf(field.getPassword()).equals(placeholder)) {
                    field.setText("");
                    field.setEchoChar('•');
                    field.setForeground(TEXT_COLOR);
                }
            }
            
            @Override
            public void focusLost(FocusEvent e) {
                if (String.valueOf(field.getPassword()).isEmpty()) {
                    field.setForeground(PLACEHOLDER_COLOR);
                    field.setEchoChar((char) 0);
                    field.setText(placeholder);
                }
            }
        });
        
        return field;
    }
    
    /**
     * Tạo Primary Button (button chính)
     */
    private JButton createPrimaryButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(PRIMARY_COLOR);
        button.setPreferredSize(new Dimension(300, 45));
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        return button;
    }
    
    /**
     * Tạo Secondary Button (button phụ)
     */
    private JButton createSecondaryButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        button.setForeground(PRIMARY_COLOR);
        button.setBackground(Color.WHITE);
        button.setPreferredSize(new Dimension(300, 45));
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(PRIMARY_COLOR, 1),
            BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }
    
    /**
     * Tạo Divider panel (đường kẻ với text "hoặc")
     */
    private JPanel createDividerPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        
        // Left line
        JSeparator leftLine = new JSeparator();
        leftLine.setPreferredSize(new Dimension(120, 1));
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        panel.add(leftLine, gbc);
        
        // "hoặc" text
        JLabel orLabel = new JLabel(" hoặc ");
        orLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        orLabel.setForeground(PLACEHOLDER_COLOR);
        gbc.gridx = 1;
        gbc.weightx = 0;
        gbc.fill = GridBagConstraints.NONE;
        panel.add(orLabel, gbc);
        
        // Right line
        JSeparator rightLine = new JSeparator();
        rightLine.setPreferredSize(new Dimension(120, 1));
        gbc.gridx = 2;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(rightLine, gbc);
        
        return panel;
    }
    
    /**
     * Thêm hiệu ứng hover cho button
     */
    private void addHoverEffect(JButton button, Color normalColor, Color hoverColor) {
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(hoverColor);
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(normalColor);
            }
        });
    }
    
    // ========================================
    // MAIN METHOD
    // ========================================
    
    /**
     * Main method - Entry point
     */
    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("  CHAT SYSTEM - LOGIN DEMO");
        System.out.println("  Student ID: 23127195");
        System.out.println("========================================");
        
        // Set Look and Feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Start GUI on Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
            
            System.out.println("✅ LoginFrame started successfully!");
            System.out.println("========================================");
        });
    }
}
