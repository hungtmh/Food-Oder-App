package gui;

import javax.swing.*;
import java.awt.*;
import dto.UserDTO;

/**
 * Main Frame - Màn hình chính sau khi đăng nhập
 * Layer: GUI (Presentation Layer)
 * 
 * Hiển thị thông tin user đã đăng nhập
 * 
 * @author 23127195
 */
public class MainFrame extends JFrame {
    
    private static final Color PRIMARY_COLOR = new Color(0, 132, 255);
    private static final Color BACKGROUND_COLOR = new Color(245, 247, 250);
    private static final Color TEXT_COLOR = new Color(51, 51, 51);
    
    private UserDTO currentUser;
    
    public MainFrame(UserDTO user) {
        this.currentUser = user;
        initializeComponents();
    }
    
    private void initializeComponents() {
        setTitle("Chat System - " + currentUser.getUsername());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BACKGROUND_COLOR);
        
        setLayout(new BorderLayout());
        
        // Header Panel
        JPanel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);
        
        // Main Content Panel
        JPanel contentPanel = createContentPanel();
        add(contentPanel, BorderLayout.CENTER);
        
        // Footer Panel
        JPanel footerPanel = createFooterPanel();
        add(footerPanel, BorderLayout.SOUTH);
    }
    
    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(PRIMARY_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        // App title
        JLabel titleLabel = new JLabel("💬 Chat System");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        panel.add(titleLabel, BorderLayout.WEST);
        
        // User info + Logout button
        JPanel userPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        userPanel.setOpaque(false);
        
        JLabel userLabel = new JLabel("👤 " + currentUser.getFullName());
        userLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        userLabel.setForeground(Color.WHITE);
        userPanel.add(userLabel);
        
        JButton logoutButton = new JButton("Đăng xuất");
        logoutButton.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        logoutButton.setForeground(PRIMARY_COLOR);
        logoutButton.setBackground(Color.WHITE);
        logoutButton.setBorderPainted(false);
        logoutButton.setFocusPainted(false);
        logoutButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logoutButton.addActionListener(e -> handleLogout());
        userPanel.add(logoutButton);
        
        panel.add(userPanel, BorderLayout.EAST);
        
        return panel;
    }
    
    private JPanel createContentPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // Welcome message
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel welcomeLabel = new JLabel("Chào mừng bạn đến với Chat System!");
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        welcomeLabel.setForeground(TEXT_COLOR);
        panel.add(welcomeLabel, gbc);
        
        // User info card
        gbc.gridy = 1;
        gbc.insets = new Insets(30, 10, 10, 10);
        JPanel infoCard = createUserInfoCard();
        panel.add(infoCard, gbc);
        
        // Demo message
        gbc.gridy = 2;
        gbc.insets = new Insets(30, 10, 10, 10);
        JLabel demoLabel = new JLabel("✅ Đăng nhập thành công! Đây là demo chức năng Login.");
        demoLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        demoLabel.setForeground(new Color(76, 175, 80));
        panel.add(demoLabel, gbc);
        
        return panel;
    }
    
    private JPanel createUserInfoCard() {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 220), 1),
            BorderFactory.createEmptyBorder(20, 30, 20, 30)
        ));
        
        // Title
        JLabel titleLabel = new JLabel("📋 Thông tin tài khoản");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setForeground(PRIMARY_COLOR);
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(titleLabel);
        
        card.add(Box.createRigidArea(new Dimension(0, 15)));
        
        // User details
        addInfoRow(card, "ID:", String.valueOf(currentUser.getId()));
        addInfoRow(card, "Username:", currentUser.getUsername());
        addInfoRow(card, "Họ tên:", currentUser.getFullName());
        addInfoRow(card, "Email:", currentUser.getEmail());
        addInfoRow(card, "Trạng thái:", currentUser.isActive() ? "✅ Hoạt động" : "🔒 Bị khóa");
        
        return card;
    }
    
    private void addInfoRow(JPanel parent, String label, String value) {
        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 5));
        row.setBackground(Color.WHITE);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        JLabel labelComp = new JLabel(label);
        labelComp.setFont(new Font("Segoe UI", Font.BOLD, 13));
        labelComp.setForeground(TEXT_COLOR);
        labelComp.setPreferredSize(new Dimension(100, 20));
        row.add(labelComp);
        
        JLabel valueComp = new JLabel(value != null ? value : "N/A");
        valueComp.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        valueComp.setForeground(TEXT_COLOR);
        row.add(valueComp);
        
        parent.add(row);
    }
    
    private JPanel createFooterPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panel.setBackground(new Color(240, 240, 240));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        JLabel footerLabel = new JLabel("© 2024 Chat System - Student ID: 23127195");
        footerLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        footerLabel.setForeground(new Color(128, 128, 128));
        panel.add(footerLabel);
        
        return panel;
    }
    
    private void handleLogout() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Bạn có chắc muốn đăng xuất?",
            "Xác nhận đăng xuất",
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            dispose();
            
            // Quay lại màn hình đăng nhập
            SwingUtilities.invokeLater(() -> {
                LoginFrame loginFrame = new LoginFrame();
                loginFrame.setVisible(true);
            });
        }
    }
}
