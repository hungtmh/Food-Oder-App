package bus;

import dao.UserDAO;
import dto.LoginResultDTO;
import dto.UserDTO;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Business Logic Layer (BUS/Service) - Xử lý nghiệp vụ đăng nhập
 * Layer: BUS (Business Logic Layer)
 * 
 * Chức năng:
 * - Xác thực thông tin đăng nhập
 * - Hash và verify mật khẩu
 * - Validation dữ liệu đầu vào
 * - Xử lý logic nghiệp vụ
 * 
 * @author 23127195
 */
public class LoginBUS {
    
    private UserDAO userDAO;
    
    public LoginBUS() {
        this.userDAO = new UserDAO();
    }
    
    /**
     * Xử lý đăng nhập
     * 
     * @param usernameOrEmail Tên đăng nhập hoặc email
     * @param password Mật khẩu (plaintext)
     * @return LoginResultDTO chứa kết quả đăng nhập
     */
    public LoginResultDTO login(String usernameOrEmail, String password) {
        System.out.println("=== LoginBUS.login() ===");
        System.out.println("   Input: " + usernameOrEmail);
        
        // 1. Validation đầu vào
        if (usernameOrEmail == null || usernameOrEmail.trim().isEmpty()) {
            return LoginResultDTO.failure("Vui lòng nhập tên đăng nhập hoặc email!");
        }
        
        if (password == null || password.isEmpty()) {
            return LoginResultDTO.failure("Vui lòng nhập mật khẩu!");
        }
        
        // 2. Tìm user trong database
        UserDTO user = userDAO.findByUsernameOrEmail(usernameOrEmail.trim());
        
        if (user == null) {
            System.out.println("   ❌ User not found");
            return LoginResultDTO.userNotFound();
        }
        
        System.out.println("   ✅ User found: " + user.getUsername());
        
        // 3. Kiểm tra tài khoản có bị khóa không
        if (user.isLocked()) {
            System.out.println("   ❌ Account is locked");
            return LoginResultDTO.accountLocked();
        }
        
        // 4. Xác thực mật khẩu
        if (!verifyPassword(password, user.getPassword())) {
            System.out.println("   ❌ Wrong password");
            return LoginResultDTO.wrongPassword();
        }
        
        System.out.println("   ✅ Password verified");
        
        // 5. Ghi lịch sử đăng nhập
        userDAO.logLoginHistory(user.getId());
        System.out.println("   ✅ Login history logged");
        
        // 6. Trả về kết quả thành công
        // Xóa password trước khi trả về
        user.setPassword(null);
        
        System.out.println("   ✅ Login SUCCESS!");
        return LoginResultDTO.success(user);
    }
    
    /**
     * Hash mật khẩu sử dụng SHA-256
     * 
     * @param password Mật khẩu plaintext
     * @return Mật khẩu đã được hash
     */
    public String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
            
        } catch (NoSuchAlgorithmException e) {
            System.err.println("❌ Lỗi hash password: " + e.getMessage());
            return password; // Fallback: trả về password gốc (không khuyến khích)
        }
    }
    
    /**
     * Xác thực mật khẩu
     * So sánh mật khẩu nhập vào với mật khẩu đã hash trong database
     * 
     * @param inputPassword Mật khẩu người dùng nhập
     * @param storedPassword Mật khẩu đã hash trong database
     * @return true nếu mật khẩu đúng
     */
    public boolean verifyPassword(String inputPassword, String storedPassword) {
        if (inputPassword == null || storedPassword == null) {
            return false;
        }
        
        // Hash mật khẩu nhập vào và so sánh
        String hashedInput = hashPassword(inputPassword);
        
        // So sánh với mật khẩu đã hash trong database
        if (hashedInput.equals(storedPassword)) {
            return true;
        }
        
        // Fallback: So sánh trực tiếp (cho trường hợp password chưa được hash)
        if (inputPassword.equals(storedPassword)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Kiểm tra username có tồn tại không
     * 
     * @param username Username cần kiểm tra
     * @return true nếu username đã tồn tại
     */
    public boolean isUsernameExists(String username) {
        return userDAO.isUsernameExists(username);
    }
    
    /**
     * Kiểm tra email có tồn tại không
     * 
     * @param email Email cần kiểm tra
     * @return true nếu email đã tồn tại
     */
    public boolean isEmailExists(String email) {
        return userDAO.isEmailExists(email);
    }
    
    /**
     * Lấy thông tin user theo username
     * 
     * @param username Username của user
     * @return UserDTO hoặc null
     */
    public UserDTO getUserByUsername(String username) {
        return userDAO.findByUsernameOrEmail(username);
    }
}
