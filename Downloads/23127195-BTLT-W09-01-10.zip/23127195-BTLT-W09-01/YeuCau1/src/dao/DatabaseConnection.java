package dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Data Access Object - Quản lý kết nối database
 * Singleton pattern để đảm bảo chỉ có 1 instance kết nối
 * 
 * @author 23127195
 */
public class DatabaseConnection {
    private static DatabaseConnection instance;
    private String url;
    private String username;
    private String password;
    
    /**
     * Private constructor - Singleton pattern
     * Load driver MySQL và đọc config
     */
    private DatabaseConnection() {
        try {
            loadConfig();
            // Load MySQL Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("✅ MySQL Driver loaded successfully!");
        } catch (ClassNotFoundException e) {
            System.err.println("❌ MySQL Driver not found!");
            System.err.println("   Please add mysql-connector-java-8.x.jar to lib folder");
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Đọc cấu hình database từ file config.properties
     */
    private void loadConfig() throws IOException {
        Properties props = new Properties();
        
        // Thử đọc từ nhiều vị trí
        String[] configPaths = {
            "config.properties",
            "resources/config.properties",
            "../config.properties"
        };
        
        for (String path : configPaths) {
            try (FileInputStream fis = new FileInputStream(path)) {
                props.load(fis);
                this.url = props.getProperty("db.url");
                this.username = props.getProperty("db.username");
                this.password = props.getProperty("db.password");
                System.out.println("✅ Config loaded from: " + path);
                System.out.println("   Database URL: " + url);
                return;
            } catch (IOException e) {
                // Thử đường dẫn tiếp theo
            }
        }
        
        // Nếu không tìm thấy file config, dùng giá trị mặc định (MySQL local)
        System.out.println("⚠️ Config file not found, using default MySQL values");
        this.url = "jdbc:mysql://localhost:3306/chat_system?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
        this.username = "root";
        this.password = "123456";
    }
    
    /**
     * Lấy instance duy nhất (Singleton)
     */
    public static synchronized DatabaseConnection getInstance() {
        if (instance == null) {
            instance = new DatabaseConnection();
        }
        return instance;
    }
    
    /**
     * Tạo kết nối mới đến database
     * 
     * @return Connection object hoặc null nếu thất bại
     */
    public Connection getConnection() {
        try {
            Connection conn = DriverManager.getConnection(url, username, password);
            return conn;
        } catch (SQLException e) {
            System.err.println("❌ Lỗi kết nối database: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Đóng kết nối an toàn
     */
    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                System.err.println("❌ Error closing connection: " + e.getMessage());
            }
        }
    }
    
    /**
     * Test kết nối database
     */
    public static void main(String[] args) {
        System.out.println("=================================");
        System.out.println("  Testing Database Connection");
        System.out.println("=================================");
        
        try {
            DatabaseConnection db = DatabaseConnection.getInstance();
            Connection conn = db.getConnection();
            
            if (conn != null) {
                System.out.println("✅ SUCCESS! Connected to database!");
                System.out.println("   Database: " + conn.getMetaData().getDatabaseProductName());
                System.out.println("   Version: " + conn.getMetaData().getDatabaseProductVersion());
                conn.close();
            } else {
                System.out.println("❌ FAILED: Connection is null");
            }
        } catch (Exception e) {
            System.out.println("❌ FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
