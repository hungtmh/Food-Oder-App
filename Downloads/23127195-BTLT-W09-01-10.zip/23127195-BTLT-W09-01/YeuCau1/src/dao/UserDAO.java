package dao;

import dto.UserDTO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object (DAO) - Xử lý truy vấn database cho User
 * Layer: DAO (Data Access Layer)
 * 
 * Chức năng:
 * - Tìm user theo username hoặc email
 * - Kiểm tra thông tin đăng nhập
 * - Ghi lịch sử đăng nhập
 * - CRUD operations cho User
 * 
 * @author 23127195
 */
public class UserDAO {
    
    private DatabaseConnection dbConnection;
    
    public UserDAO() {
        this.dbConnection = DatabaseConnection.getInstance();
    }
    
    /**
     * Tìm user theo username hoặc email
     * 
     * @param usernameOrEmail Username hoặc email của user
     * @return UserDTO nếu tìm thấy, null nếu không
     */
    public UserDTO findByUsernameOrEmail(String usernameOrEmail) {
        // Query tương thích với MySQL - dùng id và birth_date
        String sql = "SELECT id, username, password, full_name, email, address, " +
                     "birth_date, gender, status, created_at " +
                     "FROM users WHERE username = ? OR email = ?";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = dbConnection.getConnection();
            if (conn == null) {
                System.err.println("❌ Không thể kết nối database");
                return null;
            }
            
            System.out.println("✅ Database connected successfully");
            System.out.println("   Searching for: " + usernameOrEmail);
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, usernameOrEmail);
            pstmt.setString(2, usernameOrEmail);
            
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                System.out.println("   ✅ User found in database!");
                return extractUserFromResultSet(rs);
            } else {
                System.out.println("   ❌ No user found with: " + usernameOrEmail);
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Lỗi truy vấn user: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, pstmt, rs);
        }
        
        return null;
    }
    
    /**
     * Tìm user theo ID
     * 
     * @param userId ID của user
     * @return UserDTO nếu tìm thấy, null nếu không
     */
    public UserDTO findById(int userId) {
        String sql = "SELECT id, username, password, full_name, email, address, " +
                     "birth_date, gender, status, created_at " +
                     "FROM users WHERE id = ?";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = dbConnection.getConnection();
            if (conn == null) return null;
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userId);
            
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractUserFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Lỗi truy vấn user by ID: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, pstmt, rs);
        }
        
        return null;
    }
    
    /**
     * Lấy tất cả users
     * 
     * @return Danh sách UserDTO
     */
    public List<UserDTO> findAll() {
        List<UserDTO> users = new ArrayList<>();
        String sql = "SELECT id, username, password, full_name, email, address, " +
                     "birth_date, gender, status, created_at FROM users";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = dbConnection.getConnection();
            if (conn == null) return users;
            
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                users.add(extractUserFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Lỗi truy vấn all users: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, pstmt, rs);
        }
        
        return users;
    }
    
    /**
     * Kiểm tra username đã tồn tại chưa
     * 
     * @param username Username cần kiểm tra
     * @return true nếu đã tồn tại
     */
    public boolean isUsernameExists(String username) {
        String sql = "SELECT COUNT(*) FROM users WHERE username = ?";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = dbConnection.getConnection();
            if (conn == null) return false;
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Lỗi kiểm tra username: " + e.getMessage());
        } finally {
            closeResources(conn, pstmt, rs);
        }
        
        return false;
    }
    
    /**
     * Kiểm tra email đã tồn tại chưa
     * 
     * @param email Email cần kiểm tra
     * @return true nếu đã tồn tại
     */
    public boolean isEmailExists(String email) {
        String sql = "SELECT COUNT(*) FROM users WHERE email = ?";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = dbConnection.getConnection();
            if (conn == null) return false;
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, email);
            
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Lỗi kiểm tra email: " + e.getMessage());
        } finally {
            closeResources(conn, pstmt, rs);
        }
        
        return false;
    }
    
    /**
     * Thêm user mới vào database
     * 
     * @param user UserDTO chứa thông tin user
     * @return true nếu thêm thành công
     */
    public boolean insert(UserDTO user) {
        String sql = "INSERT INTO users (username, password, full_name, email, " +
                     "address, birth_date, gender, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = dbConnection.getConnection();
            if (conn == null) return false;
            
            pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPassword());
            pstmt.setString(3, user.getFullName());
            pstmt.setString(4, user.getEmail());
            pstmt.setString(5, user.getAddress());
            pstmt.setDate(6, user.getBirthDate());
            pstmt.setString(7, user.getGender());
            pstmt.setString(8, user.getStatus() != null ? user.getStatus() : "active");
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                // Lấy ID được tự động sinh
                ResultSet generatedKeys = pstmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    user.setId(generatedKeys.getInt(1));
                }
                System.out.println("✅ Thêm user thành công: " + user.getUsername());
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Lỗi thêm user: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, pstmt, null);
        }
        
        return false;
    }
    
    /**
     * Cập nhật thông tin user
     * 
     * @param user UserDTO chứa thông tin cần cập nhật
     * @return true nếu cập nhật thành công
     */
    public boolean update(UserDTO user) {
        String sql = "UPDATE users SET full_name = ?, email = ?, address = ?, " +
                     "birth_date = ?, gender = ?, status = ? WHERE id = ?";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = dbConnection.getConnection();
            if (conn == null) return false;
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, user.getFullName());
            pstmt.setString(2, user.getEmail());
            pstmt.setString(3, user.getAddress());
            pstmt.setDate(4, user.getBirthDate());
            pstmt.setString(5, user.getGender());
            pstmt.setString(6, user.getStatus());
            pstmt.setInt(7, user.getId());
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                System.out.println("✅ Cập nhật user thành công: " + user.getUsername());
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Lỗi cập nhật user: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, pstmt, null);
        }
        
        return false;
    }
    
    /**
     * Xóa user theo ID
     * 
     * @param userId ID của user cần xóa
     * @return true nếu xóa thành công
     */
    public boolean delete(int userId) {
        String sql = "DELETE FROM users WHERE id = ?";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = dbConnection.getConnection();
            if (conn == null) return false;
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userId);
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                System.out.println("✅ Xóa user thành công: ID = " + userId);
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Lỗi xóa user: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, pstmt, null);
        }
        
        return false;
    }
    
    /**
     * Ghi lịch sử đăng nhập
     * 
     * @param userId ID của user đăng nhập
     * @return true nếu ghi thành công
     */
    public boolean logLoginHistory(int userId) {
        String sql = "INSERT INTO login_history (user_id, login_time) VALUES (?, NOW())";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = dbConnection.getConnection();
            if (conn == null) return false;
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("❌ Lỗi ghi login history: " + e.getMessage());
            // Không throw exception, chỉ log lỗi
        } finally {
            closeResources(conn, pstmt, null);
        }
        
        return false;
    }
    
    /**
     * Cập nhật mật khẩu user
     * 
     * @param userId ID của user
     * @param newHashedPassword Mật khẩu mới đã được hash
     * @return true nếu cập nhật thành công
     */
    public boolean updatePassword(int userId, String newHashedPassword) {
        String sql = "UPDATE users SET password = ? WHERE id = ?";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = dbConnection.getConnection();
            if (conn == null) return false;
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, newHashedPassword);
            pstmt.setInt(2, userId);
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                System.out.println("✅ Cập nhật mật khẩu thành công: ID = " + userId);
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Lỗi cập nhật mật khẩu: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, pstmt, null);
        }
        
        return false;
    }
    
    // ========================================
    // HELPER METHODS
    // ========================================
    
    /**
     * Chuyển ResultSet thành UserDTO
     * Dùng tên cột theo schema MySQL: id, birth_date
     */
    private UserDTO extractUserFromResultSet(ResultSet rs) throws SQLException {
        UserDTO user = new UserDTO();
        user.setId(rs.getInt("id"));  // MySQL dùng id
        user.setUsername(rs.getString("username"));
        user.setPassword(rs.getString("password"));
        user.setFullName(rs.getString("full_name"));
        user.setEmail(rs.getString("email"));
        user.setAddress(rs.getString("address"));
        user.setBirthDate(rs.getDate("birth_date"));  // MySQL dùng birth_date
        user.setGender(rs.getString("gender"));
        user.setStatus(rs.getString("status"));
        user.setCreatedAt(rs.getTimestamp("created_at"));
        return user;
    }
    
    /**
     * Đóng tất cả resources an toàn
     */
    private void closeResources(Connection conn, PreparedStatement pstmt, ResultSet rs) {
        try {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            System.err.println("❌ Lỗi đóng resources: " + e.getMessage());
        }
    }
}
