@echo off
echo ========================================
echo   CREATE JAR - Login Demo (23127195)
echo ========================================

REM Build truoc
call build.bat

REM Tao manifest
echo Creating manifest...
echo Main-Class: gui.LoginFrame> manifest.txt
echo Class-Path: lib/mysql-connector-java-8.0.30.jar>> manifest.txt
echo.>> manifest.txt

REM Tao JAR
echo Creating JAR file...
cd bin
jar cvfm ..\LoginDemo.jar ..\manifest.txt *
cd ..

REM Xoa manifest tam
del manifest.txt

echo.
echo ✅ JAR created: LoginDemo.jar
echo.
echo To run: java -jar LoginDemo.jar
echo Or: double-click LoginDemo.jar (if JRE is installed)
echo.
pause
