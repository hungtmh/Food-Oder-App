@echo off
echo ========================================
echo   RUN - Login Demo (23127195)
echo ========================================
echo.

REM Kiem tra thu muc bin
if not exist bin (
    echo ❌ Bin folder not found! Please run build.bat first.
    pause
    exit /b 1
)

REM Chay ung dung
echo Starting Login Demo...
echo.
java -cp "bin;lib/*;resources" gui.LoginFrame

pause
