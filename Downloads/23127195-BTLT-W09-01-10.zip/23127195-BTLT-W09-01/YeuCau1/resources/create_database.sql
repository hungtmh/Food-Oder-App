-- =====================================================
-- Script tạo Database cho Login Demo
-- Student ID: 23127195
-- =====================================================

-- Tạo database
CREATE DATABASE IF NOT EXISTS chat_system;
USE chat_system;

-- =====================================================
-- Bảng users - Lưu thông tin người dùng
-- =====================================================
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    address TEXT,
    birth_date DATE,
    gender ENUM('Nam', 'Nữ', 'Khác'),
    status ENUM('active', 'locked') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_status (status)
);

-- =====================================================
-- Bảng login_history - Lịch sử đăng nhập
-- =====================================================
CREATE TABLE IF NOT EXISTS login_history (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(45),
    user_agent TEXT,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_login_time (login_time)
);

-- =====================================================
-- Hiển thị cấu trúc bảng
-- =====================================================
DESCRIBE users;
DESCRIBE login_history;

SELECT '✅ Database created successfully!' AS Status;
