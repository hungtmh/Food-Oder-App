-- =====================================================
-- Dữ liệu mẫu cho Login Demo
-- Student ID: 23127195
-- =====================================================

USE chat_system;

-- Xóa dữ liệu cũ (nếu có)
DELETE FROM login_history;
DELETE FROM users;

-- Reset auto increment
ALTER TABLE users AUTO_INCREMENT = 1;
ALTER TABLE login_history AUTO_INCREMENT = 1;

-- =====================================================
-- Thêm users mẫu
-- Password: 123456 (SHA-256 hash)
-- Hash của "123456": 8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92
-- =====================================================

INSERT INTO users (username, password, full_name, email, address, birth_date, gender, status) VALUES
('user1', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 'Nguyễn Văn A', 'user1@gmail.com', 'TP. Hồ Chí Minh', '2000-01-15', 'Nam', 'active'),
('user2', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 'Trần Thị B', 'user2@gmail.com', 'Hà Nội', '1999-05-20', 'Nữ', 'active'),
('user3', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 'Lê Văn C', 'user3@gmail.com', 'Đà Nẵng', '2001-12-10', 'Nam', 'active'),
('admin', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 'Administrator', 'admin@system.com', 'System', '1990-01-01', 'Nam', 'active'),
('locked_user', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 'User Bị Khóa', 'locked@gmail.com', 'TP. Hồ Chí Minh', '2000-06-15', 'Nam', 'locked');

-- User với password plaintext (để test cả 2 cách verify)
INSERT INTO users (username, password, full_name, email, address, birth_date, gender, status) VALUES
('demo', '123456', 'Demo User', 'demo@gmail.com', 'Demo Address', '2000-01-01', 'Nam', 'active');

-- =====================================================
-- Thêm lịch sử đăng nhập mẫu
-- =====================================================
INSERT INTO login_history (user_id, login_time) VALUES
(1, NOW() - INTERVAL 1 DAY),
(1, NOW() - INTERVAL 2 HOUR),
(2, NOW() - INTERVAL 3 DAY),
(3, NOW() - INTERVAL 1 WEEK);

-- =====================================================
-- Kiểm tra dữ liệu
-- =====================================================
SELECT 'Users table:' AS '';
SELECT id, username, full_name, email, status FROM users;

SELECT 'Login History:' AS '';
SELECT lh.id, u.username, lh.login_time 
FROM login_history lh 
JOIN users u ON lh.user_id = u.id;

SELECT '✅ Sample data inserted successfully!' AS Status;

-- =====================================================
-- Thông tin đăng nhập test:
-- Username: user1, user2, user3, admin, demo
-- Password: 123456
-- 
-- User bị khóa: locked_user (password: 123456)
-- =====================================================
