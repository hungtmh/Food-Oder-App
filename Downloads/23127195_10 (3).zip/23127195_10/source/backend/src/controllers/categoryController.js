const supabase = require('../config/supabase');

// GET /categories - Get all categories
const getAllCategories = async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('categories')
      .select('id, name, description')
      .order('id', { ascending: true });

    if (error) {
      throw error;
    }

    res.json({ data });
  } catch (error) {
    console.error('Error fetching categories:', error);
    res.status(500).json({ message: 'Internal server error', error: error.message });
  }
};

module.exports = {
  getAllCategories
};
