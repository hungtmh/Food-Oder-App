const supabase = require('../config/supabase');

const LIMIT = 5; // 5 tickets per page

// Validation function
const validateTicket = (data) => {
  const errors = [];

  // Title validation: 5-100 characters
  if (!data.title) {
    errors.push({ field: 'title', message: 'Title is required' });
  } else if (data.title.length < 5 || data.title.length > 100) {
    errors.push({ field: 'title', message: 'Title must be 5-100 characters' });
  }

  // Description validation: 10-1000 characters
  if (!data.description) {
    errors.push({ field: 'description', message: 'Description is required' });
  } else if (data.description.length < 10 || data.description.length > 1000) {
    errors.push({ field: 'description', message: 'Description must be 10-1000 characters' });
  }

  // Status validation
  const validStatuses = ['open', 'in_progress', 'resolved', 'closed'];
  if (!data.status) {
    errors.push({ field: 'status', message: 'Status is required' });
  } else if (!validStatuses.includes(data.status)) {
    errors.push({ field: 'status', message: 'Status must be one of: open, in_progress, resolved, closed' });
  }

  // Priority validation
  const validPriorities = ['low', 'medium', 'high'];
  if (!data.priority) {
    errors.push({ field: 'priority', message: 'Priority is required' });
  } else if (!validPriorities.includes(data.priority)) {
    errors.push({ field: 'priority', message: 'Priority must be one of: low, medium, high' });
  }

  // Customer ID validation
  if (!data.customerId) {
    errors.push({ field: 'customerId', message: 'Customer ID is required' });
  }

  // Category ID validation
  if (!data.categoryId) {
    errors.push({ field: 'categoryId', message: 'Category ID is required' });
  }

  return errors;
};

// GET /tickets - Get all tickets with pagination and filtering
const getAllTickets = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const customerId = req.query.customerId ? parseInt(req.query.customerId) : null;
    const categoryId = req.query.categoryId ? parseInt(req.query.categoryId) : null;

    const offset = (page - 1) * LIMIT;

    // Build query
    let query = supabase
      .from('tickets')
      .select('*', { count: 'exact' });

    // Apply filters
    if (customerId) {
      query = query.eq('customer_id', customerId);
    }
    if (categoryId) {
      query = query.eq('category_id', categoryId);
    }

    // Apply pagination and ordering
    query = query
      .order('created_at', { ascending: false })
      .range(offset, offset + LIMIT - 1);

    const { data, error, count } = await query;

    if (error) {
      throw error;
    }

    // Transform data to match API spec (snake_case to camelCase)
    const transformedData = data.map(ticket => ({
      id: ticket.id,
      title: ticket.title,
      description: ticket.description,
      status: ticket.status,
      priority: ticket.priority,
      customerId: ticket.customer_id,
      categoryId: ticket.category_id,
      createdAt: ticket.created_at
    }));

    res.json({
      data: transformedData,
      meta: {
        page: page,
        limit: LIMIT,
        totalItems: count
      }
    });
  } catch (error) {
    console.error('Error fetching tickets:', error);
    res.status(500).json({ message: 'Internal server error', error: error.message });
  }
};

// GET /tickets/:id - Get single ticket by ID
const getTicketById = async (req, res) => {
  try {
    const { id } = req.params;

    const { data, error } = await supabase
      .from('tickets')
      .select('*')
      .eq('id', id)
      .single();

    if (error) {
      if (error.code === 'PGRST116') {
        return res.status(404).json({ message: 'Ticket not found' });
      }
      throw error;
    }

    // Transform data
    const transformedData = {
      id: data.id,
      title: data.title,
      description: data.description,
      status: data.status,
      priority: data.priority,
      customerId: data.customer_id,
      categoryId: data.category_id,
      createdAt: data.created_at
    };

    res.json({ data: transformedData });
  } catch (error) {
    console.error('Error fetching ticket:', error);
    res.status(500).json({ message: 'Internal server error', error: error.message });
  }
};

// POST /tickets - Create new ticket
const createTicket = async (req, res) => {
  try {
    const { title, description, status, priority, customerId, categoryId } = req.body;

    // Validate input
    const errors = validateTicket({ title, description, status, priority, customerId, categoryId });

    // Check if customer exists
    if (customerId) {
      const { data: customer, error: customerError } = await supabase
        .from('customers')
        .select('id')
        .eq('id', customerId)
        .single();

      if (customerError || !customer) {
        errors.push({ field: 'customerId', message: 'Customer does not exist' });
      }
    }

    // Check if category exists
    if (categoryId) {
      const { data: category, error: categoryError } = await supabase
        .from('categories')
        .select('id')
        .eq('id', categoryId)
        .single();

      if (categoryError || !category) {
        errors.push({ field: 'categoryId', message: 'Category does not exist' });
      }
    }

    if (errors.length > 0) {
      return res.status(400).json({ message: 'Validation error', errors });
    }

    // Insert ticket
    const { data, error } = await supabase
      .from('tickets')
      .insert([{
        title,
        description,
        status,
        priority,
        customer_id: customerId,
        category_id: categoryId
      }])
      .select()
      .single();

    if (error) {
      throw error;
    }

    // Transform response
    const transformedData = {
      id: data.id,
      title: data.title,
      description: data.description,
      status: data.status,
      priority: data.priority,
      customerId: data.customer_id,
      categoryId: data.category_id,
      createdAt: data.created_at
    };

    res.status(201).json({ data: transformedData });
  } catch (error) {
    console.error('Error creating ticket:', error);
    res.status(500).json({ message: 'Internal server error', error: error.message });
  }
};

module.exports = {
  getAllTickets,
  getTicketById,
  createTicket
};
