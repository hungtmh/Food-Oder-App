const supabase = require('../config/supabase');

// GET /customers - Get all customers
const getAllCustomers = async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('customers')
      .select('id, name, email, phone')
      .order('id', { ascending: true });

    if (error) {
      throw error;
    }

    res.json({ data });
  } catch (error) {
    console.error('Error fetching customers:', error);
    res.status(500).json({ message: 'Internal server error', error: error.message });
  }
};

module.exports = {
  getAllCustomers
};
