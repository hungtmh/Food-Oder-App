const express = require('express');
const router = express.Router();
const customerController = require('../controllers/customerController');

// GET /customers - Get all customers
router.get('/', customerController.getAllCustomers);

module.exports = router;
