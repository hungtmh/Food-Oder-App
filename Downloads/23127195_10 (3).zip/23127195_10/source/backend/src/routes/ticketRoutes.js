const express = require('express');
const router = express.Router();
const ticketController = require('../controllers/ticketController');

// GET /tickets - Get all tickets with pagination and filtering
router.get('/', ticketController.getAllTickets);

// GET /tickets/:id - Get single ticket by ID
router.get('/:id', ticketController.getTicketById);

// POST /tickets - Create new ticket
router.post('/', ticketController.createTicket);

module.exports = router;
