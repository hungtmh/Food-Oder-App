require('dotenv').config();

const apiKeyAuth = (req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  const validApiKey = process.env.API_KEY;

  if (!apiKey) {
    return res.status(401).json({
      message: 'API key is required',
      error: 'Missing X-API-Key header'
    });
  }

  if (apiKey !== validApiKey) {
    return res.status(403).json({
      message: 'Invalid API key',
      error: 'The provided API key is not valid'
    });
  }

  next();
};

module.exports = apiKeyAuth;
