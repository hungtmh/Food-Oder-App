const express = require('express');
const cors = require('cors');
require('dotenv').config();

const apiKeyAuth = require('./middleware/apiKeyAuth');
const ticketRoutes = require('./routes/ticketRoutes');
const customerRoutes = require('./routes/customerRoutes');
const categoryRoutes = require('./routes/categoryRoutes');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// API Key Authentication - Apply to all routes
app.use(apiKeyAuth);

// Routes
app.use('/tickets', ticketRoutes);
app.use('/customers', customerRoutes);
app.use('/categories', categoryRoutes);

// Health check endpoint (no auth required for testing)
app.get('/health', (req, res) => {
  res.json({ status: 'OK', message: 'Ticket Management API is running' });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ message: 'Route not found' });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Internal server error', error: err.message });
});

app.listen(PORT, () => {
  console.log(`🚀 Server is running on http://localhost:${PORT}`);
  console.log(`📋 API Endpoints:`);
  console.log(`   GET  /tickets`);
  console.log(`   GET  /tickets/:id`);
  console.log(`   POST /tickets`);
  console.log(`   GET  /customers`);
  console.log(`   GET  /categories`);
});
