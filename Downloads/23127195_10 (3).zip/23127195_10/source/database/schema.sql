-- =============================================
-- TICKET MANAGEMENT SYSTEM - Database Schema
-- Run this SQL in Supabase SQL Editor
-- =============================================

-- Drop existing tables if they exist (for fresh setup)
DROP TABLE IF EXISTS tickets CASCADE;
DROP TABLE IF EXISTS customers CASCADE;
DROP TABLE IF EXISTS categories CASCADE;
DROP TYPE IF EXISTS ticket_status CASCADE;
DROP TYPE IF EXISTS ticket_priority CASCADE;

-- =============================================
-- Create Categories table (5 records)
-- =============================================
CREATE TABLE categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO categories (name, description) VALUES
('🔐 Login', 'Authentication and login issues'),
('💳 Payment', 'Billing and payment gateway problems'),
('🖥️ Server', 'Server crashes, performance issues'),
('🎨 UI/UX', 'Frontend interface and design bugs'),
('📊 Database', 'Database queries, storage issues');

-- =============================================
-- Create Customers table (5 records)
-- =============================================
CREATE TABLE customers (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO customers (name, email, phone) VALUES
('Acme Corp Japan', 'support@acme.jp', '+81-90-1234-5678'),
('Osaka Trading Co', 'info@osaka-trade.jp', '+81-80-0000-1111'),
('Tokyo Tech Solutions', 'admin@tokyotech.jp', '+81-70-1111-2222'),
('Hanoi Software JSC', 'dev@hanoisoft.vn', '+84-987-654-321'),
('Saigon Airlines IT', 'tech@saigonair.vn', '+84-28-123-4567');

-- =============================================
-- Create Enum types for Tickets
-- =============================================
CREATE TYPE ticket_status AS ENUM ('open', 'in_progress', 'resolved', 'closed');
CREATE TYPE ticket_priority AS ENUM ('low', 'medium', 'high');

-- =============================================
-- Create Tickets table (50 records)
-- =============================================
CREATE TABLE tickets (
    id SERIAL PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    status ticket_status DEFAULT 'open',
    priority ticket_priority NOT NULL,
    customer_id INTEGER NOT NULL REFERENCES customers(id),
    category_id INTEGER NOT NULL REFERENCES categories(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO tickets (title, description, status, priority, customer_id, category_id, created_at) VALUES
('Cannot login with correct password', 'User enters valid credentials but gets 403 Forbidden', 'open', 'high', 1, 1, '2025-12-29 10:00:00'),
('Stripe payment gateway timeout', 'Checkout hangs after card input, 30s timeout', 'in_progress', 'high', 2, 2, '2025-12-29 09:45:00'),
('Server 500 error /dashboard', 'Production server crashed during peak hour 8AM', 'open', 'high', 3, 3, '2025-12-29 08:30:00'),
('Mobile hamburger menu broken', 'iPhone Safari hamburger menu not responding to touch', 'resolved', 'medium', 1, 4, '2025-12-28 16:20:00'),
('Database query >10s timeout', 'SELECT * FROM orders WHERE date > NOW()-30d taking 12s', 'open', 'medium', 4, 5, '2025-12-28 14:15:00'),
('File upload size limit', 'Application consuming excessive RAM', 'open', 'high', 3, 2, '2025-12-24 04:47:00'),
('Subscription cancel fail', 'CSS animations stuttering on low-end devices', 'open', 'high', 4, 1, '2025-12-21 02:13:00'),
('Connection pool exhausted', 'Redis queries returning cache misses', 'open', 'high', 2, 5, '2025-12-27 07:28:00'),
('Docker container crash', 'All CPU cores at maximum utilization', 'open', 'low', 4, 3, '2025-12-25 04:13:00'),
('Toast notification stuck', 'Tax amounts calculated incorrectly for EU VAT', 'open', 'low', 4, 1, '2025-12-26 11:38:00'),
('Webhook timeout', 'Production server unresponsive requiring manual restart', 'closed', 'high', 1, 4, '2025-12-22 17:18:00'),
('File upload size limit', 'Database trigger not executing on INSERT', 'resolved', 'high', 2, 1, '2025-12-21 21:14:00'),
('Vacuum analyze needed', 'CSS hover states missing on interactive elements', 'open', 'low', 1, 4, '2025-12-25 14:40:00'),
('Image upload fail', 'Google OAuth flow interrupted at callback', 'resolved', 'medium', 2, 3, '2025-12-22 19:40:00'),
('OAuth Google fail', 'Custom PostgreSQL function throwing exception', 'in_progress', 'low', 4, 4, '2025-12-25 20:44:00'),
('Social login fail', 'Database connections exhausted during peak load', 'resolved', 'low', 2, 1, '2025-12-26 12:17:00'),
('Query optimization needed', 'Navigation menu fails on tablet portrait', 'resolved', 'low', 4, 4, '2025-12-28 04:16:00'),
('Dark mode glitch', 'Reset password email link expires immediately', 'resolved', 'high', 5, 4, '2025-12-27 11:14:00'),
('Dark mode glitch', 'Redis queries returning cache misses', 'closed', 'low', 1, 1, '2025-12-23 20:10:00'),
('Animation laggy', 'Reverse proxy returning gateway timeout', 'open', 'medium', 4, 5, '2025-12-28 16:16:00'),
('Social login fail', 'User cannot access account after entering credentials', 'open', 'high', 5, 3, '2025-12-26 03:18:00'),
('Nginx 502 error', 'Google OAuth flow interrupted at callback', 'closed', 'low', 3, 5, '2025-12-23 16:58:00'),
('Subscription cancel fail', 'Upload size restriction too conservative', 'resolved', 'high', 5, 5, '2025-12-24 04:23:00'),
('Toast notification stuck', 'Google OAuth flow interrupted at callback', 'open', 'high', 3, 4, '2025-12-21 03:59:00'),
('Image upload fail', 'Automated backup process terminating early', 'in_progress', 'low', 2, 5, '2025-12-22 02:46:00'),
('Refund processing delay', 'Complex query running longer than expected SLA', 'in_progress', 'low', 4, 5, '2025-12-23 08:33:00'),
('Search autocomplete slow', 'Reverse proxy returning gateway timeout', 'in_progress', 'high', 2, 3, '2025-12-27 21:41:00'),
('Image upload fail', 'Custom web fonts not loading consistently', 'closed', 'low', 2, 2, '2025-12-22 10:01:00'),
('Docker container crash', 'Facebook login returns invalid token', 'in_progress', 'high', 2, 1, '2025-12-22 22:40:00'),
('UI layout broken', 'Database connections exhausted during peak load', 'open', 'low', 3, 1, '2025-12-24 08:42:00'),
('Refund processing delay', 'Navigation menu fails on tablet portrait', 'in_progress', 'high', 5, 5, '2025-12-28 07:50:00'),
('Email verification fail', 'Card BIN validation rejecting valid numbers', 'in_progress', 'low', 1, 4, '2025-12-26 13:26:00'),
('Table join slow', 'Account overdraft protection not triggering', 'open', 'high', 1, 1, '2025-12-27 23:21:00'),
('Subscription cancel fail', 'Reset password email link expires immediately', 'in_progress', 'low', 5, 4, '2025-12-23 13:11:00'),
('CPU 100% usage', 'Multi-table JOIN query performance degradation', 'in_progress', 'low', 4, 5, '2025-12-22 01:41:00'),
('Stored procedure error', 'User cannot access account after entering credentials', 'open', 'low', 2, 4, '2025-12-28 15:13:00'),
('Captcha not loading', 'Layout shifts on mobile devices', 'in_progress', 'medium', 1, 4, '2025-12-25 14:18:00'),
('Nginx 502 error', 'Query planner not using table partitions', 'closed', 'low', 2, 3, '2025-12-24 01:37:00'),
('Kubernetes pod evicted', 'Custom PostgreSQL function throwing exception', 'open', 'high', 3, 1, '2025-12-21 18:30:00'),
('Redis cache miss', 'Modal backdrop remains after close animation', 'in_progress', 'low', 5, 1, '2025-12-23 02:38:00'),
('Query optimization needed', 'CSS animations stuttering on low-end devices', 'in_progress', 'medium', 1, 5, '2025-12-24 18:38:00'),
('Server restart needed', 'Database trigger not executing on INSERT', 'open', 'medium', 5, 5, '2025-12-26 08:13:00'),
('SSL certificate expired', 'Multi-factor setup wizard crashes on step 3', 'resolved', 'low', 3, 4, '2025-12-23 21:41:00'),
('Backup script failed', 'Multi-table JOIN query performance degradation', 'resolved', 'low', 1, 4, '2025-12-22 02:34:00'),
('Responsive menu fail', 'Redis queries returning cache misses', 'resolved', 'low', 3, 1, '2025-12-24 11:18:00'),
('OAuth Google fail', 'Custom web fonts not loading consistently', 'resolved', 'high', 5, 1, '2025-12-25 21:06:00'),
('Dark mode glitch', 'External webhook endpoint timing out consistently', 'open', 'low', 5, 2, '2025-12-25 09:38:00'),
('Responsive menu fail', 'Multi-factor setup wizard crashes on step 3', 'resolved', 'low', 3, 5, '2025-12-28 08:57:00'),
('UI layout broken', 'Cannot enable two-factor authentication', 'closed', 'medium', 1, 1, '2025-12-26 04:40:00'),
('Webhook timeout', 'Google OAuth flow interrupted at callback', 'closed', 'high', 4, 5, '2025-12-21 03:04:00');

-- =============================================
-- Enable Row Level Security (optional but recommended)
-- =============================================
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE tickets ENABLE ROW LEVEL SECURITY;

-- Create policies to allow all operations (for simplicity)
CREATE POLICY "Allow all operations on categories" ON categories FOR ALL USING (true);
CREATE POLICY "Allow all operations on customers" ON customers FOR ALL USING (true);
CREATE POLICY "Allow all operations on tickets" ON tickets FOR ALL USING (true);
