import axios from 'axios';

const API_BASE_URL = 'http://localhost:3001';
const API_KEY = 'my_super_secret_api_key_12345'; // PHẢI TRÙNG VỚI backend/.env

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
    'X-API-Key': API_KEY
  }
});

// Tickets API
export const getTickets = async (page = 1, customerId = null, categoryId = null) => {
  const params = new URLSearchParams();
  params.append('page', page);
  if (customerId) params.append('customerId', customerId);
  if (categoryId) params.append('categoryId', categoryId);
  
  const response = await api.get(`/tickets?${params.toString()}`);
  return response.data;
};

export const getTicketById = async (id) => {
  const response = await api.get(`/tickets/${id}`);
  return response.data;
};

export const createTicket = async (ticketData) => {
  const response = await api.post('/tickets', ticketData);
  return response.data;
};

// Customers API
export const getCustomers = async () => {
  const response = await api.get('/customers');
  return response.data;
};

// Categories API
export const getCategories = async () => {
  const response = await api.get('/categories');
  return response.data;
};

export default api;
