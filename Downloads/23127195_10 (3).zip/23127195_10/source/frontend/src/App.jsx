import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import TicketList from './pages/TicketList';
import TicketForm from './pages/TicketForm';

function App() {
  return (
    <Router>
      <div className="bg-gray-50 min-h-screen">
        <Navbar />
        <Routes>
          <Route path="/" element={<TicketList />} />
          <Route path="/tickets" element={<TicketList />} />
          <Route path="/create" element={<TicketForm />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
