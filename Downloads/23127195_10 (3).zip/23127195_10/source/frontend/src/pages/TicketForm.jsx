import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createTicket, getCustomers, getCategories } from '../services/api';

function TicketForm() {
  const navigate = useNavigate();
  const [customers, setCustomers] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  
  // Form data
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    status: '',
    priority: '',
    customerId: '',
    categoryId: ''
  });

  // Form errors
  const [errors, setErrors] = useState({});

  // Fetch customers and categories on mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [customersRes, categoriesRes] = await Promise.all([
          getCustomers(),
          getCategories()
        ]);
        setCustomers(customersRes.data);
        setCategories(categoriesRes.data);
      } catch (err) {
        console.error('Error fetching data:', err);
      }
    };
    fetchData();
  }, []);

  // Validate form
  const validateForm = () => {
    const newErrors = {};

    // Title validation: 5-100 characters
    if (!formData.title) {
      newErrors.title = 'Tiêu đề là bắt buộc';
    } else if (formData.title.length < 5) {
      newErrors.title = 'Tiêu đề phải có ít nhất 5 ký tự';
    } else if (formData.title.length > 100) {
      newErrors.title = 'Tiêu đề không được quá 100 ký tự';
    }

    // Description validation: 10-1000 characters
    if (!formData.description) {
      newErrors.description = 'Mô tả là bắt buộc';
    } else if (formData.description.length < 10) {
      newErrors.description = 'Mô tả phải có ít nhất 10 ký tự';
    } else if (formData.description.length > 1000) {
      newErrors.description = 'Mô tả không được quá 1000 ký tự';
    }

    // Status validation
    if (!formData.status) {
      newErrors.status = 'Trạng thái là bắt buộc';
    }

    // Priority validation
    if (!formData.priority) {
      newErrors.priority = 'Mức ưu tiên là bắt buộc';
    }

    // Customer ID validation
    if (!formData.customerId) {
      newErrors.customerId = 'Khách hàng là bắt buộc';
    }

    // Category ID validation
    if (!formData.categoryId) {
      newErrors.categoryId = 'Danh mục là bắt buộc';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Check if form is valid for enabling submit button
  const isFormValid = () => {
    return (
      formData.title.length >= 5 &&
      formData.title.length <= 100 &&
      formData.description.length >= 10 &&
      formData.description.length <= 1000 &&
      formData.status &&
      formData.priority &&
      formData.customerId &&
      formData.categoryId
    );
  };

  // Handle input change
  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [id]: value
    }));
    
    // Clear error when user starts typing
    if (errors[id]) {
      setErrors(prev => ({
        ...prev,
        [id]: ''
      }));
    }
  };

  // Handle form submit
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setLoading(true);
    try {
      const ticketData = {
        title: formData.title,
        description: formData.description,
        status: formData.status,
        priority: formData.priority,
        customerId: parseInt(formData.customerId),
        categoryId: parseInt(formData.categoryId)
      };

      const response = await createTicket(ticketData);
      
      setSubmitSuccess(true);
      
      // Calculate which page the new ticket will be on (newest first, so page 1)
      // Navigate to the ticket list with page 1
      setTimeout(() => {
        navigate('/tickets?page=1');
      }, 1500);
      
    } catch (err) {
      console.error('Error creating ticket:', err);
      
      if (err.response?.data?.errors) {
        // Handle validation errors from server
        const serverErrors = {};
        err.response.data.errors.forEach(error => {
          serverErrors[error.field] = error.message;
        });
        setErrors(serverErrors);
      } else {
        setErrors({ submit: err.response?.data?.message || 'Không thể tạo ticket. Vui lòng thử lại.' });
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="pt-20 pb-12 max-w-2xl mx-auto px-4">
      {/* Success Message */}
      {submitSuccess && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
          <strong>Thành công!</strong> Ticket đã được tạo. Đang chuyển hướng...
        </div>
      )}

      {/* Form */}
      <div className="bg-white shadow-sm rounded-lg p-8 border border-gray-200">
        <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">➕ Tạo Ticket mới</h2>
        
        {errors.submit && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
            <strong>Lỗi:</strong> {errors.submit}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Title */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Tiêu đề * (5-100 ký tự)
            </label>
            <input 
              id="title"
              type="text" 
              value={formData.title}
              onChange={handleChange}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                errors.title ? 'border-red-500' : 'border-gray-300'
              }`}
              placeholder="Nhập tiêu đề ticket"
            />
            <div className="flex justify-between mt-1">
              {errors.title && (
                <p className="text-sm text-red-600">{errors.title}</p>
              )}
              <p className="text-sm text-gray-500 ml-auto">{formData.title.length}/100</p>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Mô tả * (10-1000 ký tự)
            </label>
            <textarea 
              id="description"
              rows="4" 
              value={formData.description}
              onChange={handleChange}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                errors.description ? 'border-red-500' : 'border-gray-300'
              }`}
              placeholder="Mô tả chi tiết vấn đề"
            />
            <div className="flex justify-between mt-1">
              {errors.description && (
                <p className="text-sm text-red-600">{errors.description}</p>
              )}
              <p className="text-sm text-gray-500 ml-auto">{formData.description.length}/1000</p>
            </div>
          </div>

          {/* Status & Priority */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Trạng thái *</label>
              <select 
                id="status"
                value={formData.status}
                onChange={handleChange}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                  errors.status ? 'border-red-500' : 'border-gray-300'
                }`}
              >
                <option value="">Chọn trạng thái</option>
                <option value="open">🔴 Mở</option>
                <option value="in_progress">🟡 Đang xử lý</option>
                <option value="resolved">🟢 Đã giải quyết</option>
                <option value="closed">⚫ Đóng</option>
              </select>
              {errors.status && (
                <p className="mt-1 text-sm text-red-600">{errors.status}</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Ưu tiên *</label>
              <select 
                id="priority"
                value={formData.priority}
                onChange={handleChange}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                  errors.priority ? 'border-red-500' : 'border-gray-300'
                }`}
              >
                <option value="">Chọn ưu tiên</option>
                <option value="low">🟢 Thấp</option>
                <option value="medium">🟡 Trung bình</option>
                <option value="high">🔴 Cao</option>
              </select>
              {errors.priority && (
                <p className="mt-1 text-sm text-red-600">{errors.priority}</p>
              )}
            </div>
          </div>

          {/* Customer & Category */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Khách hàng *</label>
              <select 
                id="customerId"
                value={formData.customerId}
                onChange={handleChange}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                  errors.customerId ? 'border-red-500' : 'border-gray-300'
                }`}
              >
                <option value="">Chọn khách hàng</option>
                {customers.map(customer => (
                  <option key={customer.id} value={customer.id}>{customer.name}</option>
                ))}
              </select>
              {errors.customerId && (
                <p className="mt-1 text-sm text-red-600">{errors.customerId}</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Danh mục *</label>
              <select 
                id="categoryId"
                value={formData.categoryId}
                onChange={handleChange}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                  errors.categoryId ? 'border-red-500' : 'border-gray-300'
                }`}
              >
                <option value="">Chọn danh mục</option>
                {categories.map(category => (
                  <option key={category.id} value={category.id}>{category.name}</option>
                ))}
              </select>
              {errors.categoryId && (
                <p className="mt-1 text-sm text-red-600">{errors.categoryId}</p>
              )}
            </div>
          </div>

          {/* Submit Button */}
          <button 
            type="submit" 
            disabled={!isFormValid() || loading}
            className={`w-full py-3 px-6 rounded-lg font-semibold focus:ring-2 ${
              isFormValid() && !loading
                ? 'bg-green-600 text-white hover:bg-green-700'
                : 'bg-gray-400 text-gray-200 cursor-not-allowed'
            }`}
          >
            {loading ? (
              <span className="flex items-center justify-center">
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Đang tạo...
              </span>
            ) : (
              '✅ Tạo Ticket mới'
            )}
          </button>
        </form>
      </div>
    </div>
  );
}

export default TicketForm;
