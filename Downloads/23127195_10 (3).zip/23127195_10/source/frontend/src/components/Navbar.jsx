import { Link, useLocation } from 'react-router-dom';

function Navbar() {
  const location = useLocation();
  
  return (
    <nav className="bg-white shadow-sm border-b fixed w-full top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <Link to="/" className="text-2xl font-bold text-gray-900">
            🎫 Ticket Management
          </Link>
          <div className="flex space-x-3">
            <Link 
              to="/tickets" 
              className={`px-6 py-2 rounded-lg font-medium shadow-sm ${
                location.pathname === '/tickets' || location.pathname === '/'
                  ? 'bg-blue-600 text-white hover:bg-blue-700'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              📋 Danh sách
            </Link>
            <Link 
              to="/create" 
              className={`px-6 py-2 rounded-lg font-medium shadow-sm ${
                location.pathname === '/create'
                  ? 'bg-green-600 text-white hover:bg-green-700'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              ➕ Tạo mới
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
