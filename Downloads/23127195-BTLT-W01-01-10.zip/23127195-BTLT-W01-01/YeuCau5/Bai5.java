import java.util.*;
public class Bai5 {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        Set<String> users=new HashSet<>();
        int totalPoints=0;
        while (sc.hasNextLine())
        {
            String line=sc.nextLine();
            if (line.length()==0) break;
            if (line.charAt(0)=='+'){
                users.add(line.substring(1));
            }
            else if (line.charAt(0)=='-'){
                users.remove(line.substring(1));
            }
            else {
                int index=line.indexOf(':');
                String message=line.substring(index+1);
                totalPoints+=message.length()*users.size();
            }

        }
        System.out.println(totalPoints);
    }
}
