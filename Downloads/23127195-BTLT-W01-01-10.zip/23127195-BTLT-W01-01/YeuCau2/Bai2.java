import java.util.*;

public class Bai2 {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        String[] names=new String[n];
        int[] scores=new int[n];
        for(int i=0;i<n;i++){
            names[i]=sc.next();
            scores[i]=sc.nextInt();
        }
        sc.close();
        Map<String,Integer> totalPoints=new HashMap<>();
        for (int i=0;i<n;i++){
            totalPoints.put(names[i],totalPoints.getOrDefault(names[i],0)+scores[i]);
        }
        int maxScore=Integer.MIN_VALUE;
        for (int score:totalPoints.values()){
            if (score>maxScore){
                maxScore=score;
            }
        }
        Map<String,Integer> currentPoints=new HashMap<>();
        for (int i=0;i<n;i++){
            String name=names[i];
            int current=currentPoints.getOrDefault(name,0)+scores[i];
            currentPoints.put(name,current);
            if (current>=maxScore && totalPoints.get(name)==maxScore){
                System.out.println(name);
                break;
            }
        }
    }
}
