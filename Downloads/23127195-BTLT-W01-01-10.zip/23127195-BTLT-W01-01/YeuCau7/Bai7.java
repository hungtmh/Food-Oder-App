import java.util.*;

public class Bai7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] board = new String[8];
        for (int i = 0; i < 8; i++) {
            board[i] = sc.nextLine().trim();
        }
        sc.close();

        int rowCount = 0;
        int colCount = 0;
        
        
        for (int i = 0; i < 8; i++) {
            boolean allBlack = true;
            for (int j = 0; j < 8; j++) {
                if (board[i].charAt(j) != 'B') {
                    allBlack = false;
                    break;
                }
            }
            if (allBlack) {
                rowCount++;
            }
        }
        
        
        for (int j = 0; j < 8; j++) {
            boolean allBlack = true;
            for (int i = 0; i < 8; i++) {
                if (board[i].charAt(j) != 'B') {
                    allBlack = false;
                    break;
                }
            }
            if (allBlack) {
                colCount++;
            }
        }
        
        
        if (rowCount == 8 || colCount == 8) {
            System.out.println(8);
        } else {
            System.out.println(rowCount + colCount);
        }
    }
}
