import java.util.Scanner;

public class Bai1{
    public static void main(String [] args)
    {
        Scanner sc=new Scanner(System.in);
        long m=sc.nextLong();
        long n=sc.nextLong();
        long a=sc.nextLong();
        sc.close();

        long rows=(m+a-1)/a;
        long cols=(n+a-1)/a;
        System.out.println(rows*cols);
    }
}