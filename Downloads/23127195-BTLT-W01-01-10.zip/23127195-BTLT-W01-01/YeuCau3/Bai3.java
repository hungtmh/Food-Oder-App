import java.util.*;
public class Bai3 {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        String from=sc.nextLine();
        String to=sc.nextLine();

        int sx=from.charAt(0)-'a'+1;
        int sy=from.charAt(1)-'0';

        int ex=to.charAt(0)-'a'+1;
        int ey=to.charAt(1)-'0';
        sc.close();
        int res=Math.max(Math.abs(sx-ex),Math.abs(sy-ey));
        System.out.println(res);
        while (sx!=ex||sy!=ey){
            StringBuilder step=new StringBuilder();
            if (sx<ex){
                step.append("R");
                sx++;
            }
            else if (sx>ex){
                step.append("L");
                sx--;
            }
            if (sy<ey){
                step.append("U");
                sy++;
            }
            else if (sy>ey){
                step.append("D");
                sy--;
            }
            System.out.println(step);
        }
    }
}
