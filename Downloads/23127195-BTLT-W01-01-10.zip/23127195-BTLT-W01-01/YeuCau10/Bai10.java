import java.util.*;

public class Bai10 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int P1 = sc.nextInt();
        int P2 = sc.nextInt();
        int P3 = sc.nextInt();
        int T1 = sc.nextInt();
        int T2 = sc.nextInt();

        int[] l = new int[n];
        int[] r = new int[n];
        for (int i = 0; i < n; i++) {
            l[i] = sc.nextInt();
            r[i] = sc.nextInt();
        }
        sc.close();

        long total = 0;

        
        for (int i = 0; i < n; i++) {
            total += 1L * P1 * (r[i] - l[i]);
        }

        
        for (int i = 0; i + 1 < n; i++) {
            int d = l[i + 1] - r[i]; 
            if (d <= 0) continue; 
            int first = Math.min(d, T1);
            total += 1L * first * P1;
            int rem = d - first;
            if (rem > 0) {
                int second = Math.min(rem, T2);
                total += 1L * second * P2;
                rem -= second;
                if (rem > 0) {
                    total += 1L * rem * P3;
                }
            }
        }

        System.out.println(total);
    }
}
