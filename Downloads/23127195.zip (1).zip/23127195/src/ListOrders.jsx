import { useState, useEffect, useContext } from 'react'
import { ClipLoader } from 'react-spinners'
import ApiContext from './ApiContext'

export default function ListOrders({ setCurrentPage }) {
  // Load API url and key from context
  const api = useContext(ApiContext);

  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [provinces, setProvinces] = useState([]);
  const [wards, setWards] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

   useEffect(() => {
    // Fetch data with province and ward pre-load
    fetch(`https://yryeegjazuzurmepnkbg.supabase.co/rest/v1/courses?select=*,instructors(*),levels(*)`, {
      headers: {
        apikey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlyeWVlZ2phenV6dXJtZXBua2JnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM1NDA0NjEsImV4cCI6MjA3OTExNjQ2MX0.yMJVAg6paDX06FGJU1MxZFPySk8Vo4a6iF57qd-hOSg',
        'Content-Type': 'application/json'
      },
    }).then(async (result) => {
      if (result.status === 200) {
        setLoading(false);
        setOrders(await result.json());
      } else {
        console.error('Cannot load order data:', result);
      }
    });
  }, []);

  const handleDelete = (orderId) => {
    if (confirm('Are you sure you want to delete this order?')) {
      fetch(`${api.url}/orders?id=eq.${orderId}`, {
        method: 'DELETE',
        headers: {
          apikey: api.key,
        },
      }).then((result) => {
        if (result.status === 204) {
          alert('Order deleted successfully!');
          fetchOrders();
        } else {
          alert('Failed to delete order!');
          console.error(result);
        }
      });
    }
  };

  const handleToggleComplete = (orderId, currentStatus) => {
    fetch(`${api.url}/orders?id=eq.${orderId}`, {
      method: 'PATCH',
      headers: {
        apikey: api.key,
        'Content-Type': 'application/json',
        'Prefer': 'return=minimal',
      },
      body: JSON.stringify({
        completed: !currentStatus,
      }),
    }).then(async (result) => {
      if (result.status === 204) {
        fetchOrders();
      } else {
        const errorText = await result.text();
        alert('Failed to update order status!');
        console.error('Error response:', result.status, errorText);
      }
    });
  };

  const handleEdit = (order) => {
    setEditingId(order.id);
    setEditForm({
      recipient: order.recipient,
      house_number: order.house_number,
      street: order.street,
      province_id: order.province_id,
      ward_id: order.ward_id,
    });
    // Load wards for the selected province
    fetch(`${api.url}/wards?province_id=eq.${order.province_id}&order=name_with_type.asc`, {
      headers: {
        apikey: api.key,
      },
    }).then(async (result) => {
      if (result.status === 200) {
        setWards(await result.json());
      }
    });
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditForm({});
    setWards([]);
  };

  const handleSaveEdit = (orderId) => {
    fetch(`${api.url}/orders?id=eq.${orderId}`, {
      method: 'PATCH',
      headers: {
        apikey: api.key,
        'Content-Type': 'application/json',
        'Prefer': 'return=minimal',
      },
      body: JSON.stringify(editForm),
    }).then((result) => {
      if (result.status === 204) {
        alert('Order updated successfully!');
        setEditingId(null);
        setEditForm({});
        setWards([]);
        fetchOrders();
      } else {
        alert('Failed to update order!');
        console.error(result);
      }
    });
  };

  const handleProvinceChange = (provinceId) => {
    setEditForm({ ...editForm, province_id: provinceId, ward_id: '' });
    // Load wards for the new province
    fetch(`${api.url}/wards?province_id=eq.${provinceId}&order=name_with_type.asc`, {
      headers: {
        apikey: api.key,
      },
    }).then(async (result) => {
      if (result.status === 200) {
        setWards(await result.json());
      }
    });
  };

  // Filter orders based on search term
  const filteredOrders = orders.filter((order) => {
    if (!searchTerm) return true;
    
    const search = searchTerm.toLowerCase();
    return (
      order.id.toString().includes(search) ||
      order.recipient.toLowerCase().includes(search) ||
      order.house_number.toLowerCase().includes(search) ||
      order.street.toLowerCase().includes(search) ||
      order.ward.name_with_type.toLowerCase().includes(search) ||
      order.province.name_with_type.toLowerCase().includes(search)
    );
  });

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
  
  <div className="flex justify-between items-center mb-8">
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-2">
        <i className="fas fa-graduation-cap text-blue-600 mr-2" />
        All Courses
      </h1>
      <p className="text-gray-600">Browse and explore our collection of courses</p>
    </div>
    <button onClick={() => setCurrentPage('ShippingForm')} className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors shadow-md hover:shadow-lg">
      <i className="fas fa-plus-circle" />
      <span>Create New Course</span>
    </button>
  </div>

  <section className="bg-white rounded-xl shadow-sm border border-gray-100 mb-8">
    <div className="px-6 py-5 flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
      <div>
        <p className="text-xs uppercase tracking-wide text-blue-600 font-semibold mb-1">Smart filters</p>
        <h2 className="text-lg font-semibold text-gray-900">Refine the courses list</h2>
        <p className="text-sm text-gray-500">Combine level and instructor filters to quickly surface the right match.</p>
      </div>
      <div className="flex flex-col sm:flex-row gap-4 w-full lg:w-auto">
        <div className="flex-1 min-w-[220px]">
          <label htmlFor="levelFilter" className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2 block">Course
            level</label>
          <div className="relative">
            <i className="fas fa-layer-group absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm" />
            <select id="levelFilter" name="levelFilter" className="w-full rounded-lg border border-gray-200 bg-gray-50 pl-10 pr-4 py-2.5 text-gray-800 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition">
              <option value="all">All Levels</option>
              <option value="beginner">Beginner</option>
              <option value="intermediate">Intermediate</option>
              <option value="advanced">Advanced</option>
            </select>
          </div>
        </div>
        <div className="flex-1 min-w-[220px]">
          <label htmlFor="instructorFilter" className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2 block">Instructor</label>
          <div className="relative">
            <i className="fas fa-user-graduate absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm" />
            <select id="instructorFilter" name="instructorFilter" className="w-full rounded-lg border border-gray-200 bg-gray-50 pl-10 pr-4 py-2.5 text-gray-800 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition">
              <option value="yash-thakker">Yash Thakker</option>
              <option value="scott-duffy">Scott Duffy</option>
              <option value="tracey-barron">Tracey Barron</option>
              <option value="dfa-course-academy">DFA Course Academy</option>
              <option value="gopaluni-sai-karthik">Gopaluni Sai Karthik</option>
              <option value="anton-voroniuk">Anton Voroniuk</option>
              <option value="start-tech-academy">Start-Tech Academy</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  </section>
   <ul className="space-y-4">
          {orders.map((o) => (
            <li className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300 mb-6 overflow-hidden">
              <p><span className="font-semibold">Order ID:</span> #{o.title}</p>
              <p><span className="font-semibold">Recipient:</span> {o.description}</p>
                  <div className="flex flex-col md:flex-row">
                    <div className="md:w-1/3 relative">
                      <img src={`${o.image_url}`} alt="Complete Google NotebookLM Course 2025" className="w-full h-full object-cover" />
                      <div className="absolute top-4 left-4 flex gap-2">
                        <i className="fas fa-book-open text-white text-2xl drop-shadow-lg" />
                        <i className="fas fa-bullhorn text-white text-2xl drop-shadow-lg" />
                      </div>
                      <div className="absolute bottom-4 left-4">
                        <i className="fas fa-chart-line text-white text-2xl drop-shadow-lg" />
                      </div>
                      <div className="absolute bottom-4 right-4">
                        <i className="fab fa-youtube text-white text-3xl drop-shadow-lg" />
                      </div>
                    </div>
                  
                    <div className="md:w-2/3 p-6 flex flex-col justify-between">
                      <div>
                        <h2 className="text-xl font-bold text-gray-900 mb-2">
                          {o.title}
                        </h2>
                        <p className="text-gray-600 mb-3">
                          {o.description}
                        </p>
                        <p className="text-sm text-gray-700 mb-2">{o.instructor_id}</p>
                      
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-orange-600 font-bold">{o.rating}</span>
                          <div className="flex text-orange-500">
                            <i className="fas fa-star" />
                            <i className="fas fa-star" />
                            <i className="fas fa-star" />
                            <i className="fas fa-star" />
                            <i className="fas fa-star-half-alt" />
                          </div>
                          <span className="text-gray-600 text-sm">({o.total_reviews})</span>
                        </div>
                      
                        <div className="flex flex-wrap gap-2 text-sm text-gray-600">
                          <span>{o.total_hours} total hours</span>
                          <span>•</span>
                          <span>{o.total_lectures} lectures</span>
                          <span>•</span>
                          <span>All Levels</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-end gap-2 mt-4">
                        <span className="text-2xl font-bold text-gray-900">₫{o.current_price}</span>
                        <span className="text-lg text-gray-400 line-through">₫{o.original_price}</span>
                      </div>
                    </div>
                  </div>
            </li>
          ))}
    </ul>
  
</div>
  )
}
