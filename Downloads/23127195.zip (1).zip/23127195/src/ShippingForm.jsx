import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useContext, useEffect, useState } from 'react'
import ApiContext from './ApiContext'

export default function ShippingForm({ setCurrentPage }) {
  // Load API url and key from context
  const api = useContext(ApiContext);

  // Empty list provinces and wards
  const [provinces, setProvinces] = useState([]);
  const [wards, setWards] = useState([]);

  // Zod schema for validation
  const schema = z.object({
    recipient: z.string().min(3, 'Recipent is required'),
    houseNumber: z.string().min(1, 'House number is required'),
    street: z.string().min(1, 'Street is required'),
    // Pre-process to number
    province: z.preprocess(val => (typeof val === "string" ? Number(val) : val), z.number()),
    ward: z.preprocess(val => (typeof val === "string" ? Number(val) : val), z.number()),
  });

  // Preload provinces data
  useEffect(() => {
    fetch(`${api.url}/provinces`, {
      headers: {
        apikey: api.key,
      },
    }).then(async (result) => {
      if (result.status === 200) {
        // Update list province
        setProvinces(await result.json());
      } else {
        console.error('Cannot load province data:', result);
      }
    });
  }, []);

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(schema),
  });

  const selectedProvince = watch('province');

  // Update ward when province changes
  useEffect(() => {
    // Reset ward selection
    setValue('ward', '');
    setWards([]);
    if (selectedProvince && selectedProvince.length > 0) {
      // Filter ward by province id and sort by name
      fetch(`${api.url}/wards?province_id=eq.${selectedProvince}&order=name_with_type.asc`, {
        headers: {
          apikey: api.key,
        },
      }).then(async (result) => {
        if (result.status === 200) {
          // Update list wards
          setWards(await result.json());
        } else {
          console.error('Cannot load ward data:', result);
        }
      });
    }
  }, [selectedProvince, setValue]);

  const onSubmit = (data) => {
    console.log(data);
    // Submit data to API
    fetch(`${api.url}/orders`, {
      // Must use POST to submit data
      method: 'POST',
      headers: {
        apikey: api.key,
        // Must be JSON
        'Content-Type': 'application/json',
      },
      // Create JSON from object
      body: JSON.stringify({
        recipient: data.recipient,
        house_number: data.houseNumber,
        street: data.street,
        province_id: data.province,
        ward_id: data.ward,
      }),
    }).then((result) => {
      // 201 => Created
      if (result.status === 201) {
        alert('Create new shipping order successfully!');
      } else {
        alert('Something went wrong! Check the console!');
        console.error(result);
      }
    });
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
  {/* Header with Create Button */}
  <div className="flex justify-between items-center mb-8">
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-2">
        <i className="fas fa-graduation-cap text-blue-600 mr-2" />
        All Courses
      </h1>
      <p className="text-gray-600">Browse and explore our collection of courses</p>
    </div>
    <a href="create-course.html" className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors shadow-md hover:shadow-lg">
      <i className="fas fa-plus-circle" />
      <span>Create New Course</span>
    </a>
  </div>
  {/* Filters */}
  <section className="bg-white rounded-xl shadow-sm border border-gray-100 mb-8">
    <div className="px-6 py-5 flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
      <div>
        <p className="text-xs uppercase tracking-wide text-blue-600 font-semibold mb-1">Smart filters</p>
        <h2 className="text-lg font-semibold text-gray-900">Refine the courses list</h2>
        <p className="text-sm text-gray-500">Combine level and instructor filters to quickly surface the right match.</p>
      </div>
      <div className="flex flex-col sm:flex-row gap-4 w-full lg:w-auto">
        <div className="flex-1 min-w-[220px]">
          <label htmlFor="levelFilter" className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2 block">Course
            level</label>
          <div className="relative">
            <i className="fas fa-layer-group absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm" />
            <select id="levelFilter" name="levelFilter" className="w-full rounded-lg border border-gray-200 bg-gray-50 pl-10 pr-4 py-2.5 text-gray-800 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition">
              <option value="all">All Levels</option>
              <option value="beginner">Beginner</option>
              <option value="intermediate">Intermediate</option>
              <option value="advanced">Advanced</option>
            </select>
          </div>
        </div>
        <div className="flex-1 min-w-[220px]">
          <label htmlFor="instructorFilter" className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2 block">Instructor</label>
          <div className="relative">
            <i className="fas fa-user-graduate absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm" />
            <select id="instructorFilter" name="instructorFilter" className="w-full rounded-lg border border-gray-200 bg-gray-50 pl-10 pr-4 py-2.5 text-gray-800 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition">
              <option value="yash-thakker">Yash Thakker</option>
              <option value="scott-duffy">Scott Duffy</option>
              <option value="tracey-barron">Tracey Barron</option>
              <option value="dfa-course-academy">DFA Course Academy</option>
              <option value="gopaluni-sai-karthik">Gopaluni Sai Karthik</option>
              <option value="anton-voroniuk">Anton Voroniuk</option>
              <option value="start-tech-academy">Start-Tech Academy</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Course Card 1 */}
  <div className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300 mb-6 overflow-hidden">
    <div className="flex flex-col md:flex-row">
      {/* Course Image */}
      <div className="md:w-1/3 relative">
        <img src="https://images.unsplash.com/photo-1677442136019-21780ecad995?w=400&h=300&fit=crop" alt="Complete Google NotebookLM Course 2025" className="w-full h-full object-cover" />
        <div className="absolute top-4 left-4 flex gap-2">
          <i className="fas fa-book-open text-white text-2xl drop-shadow-lg" />
          <i className="fas fa-bullhorn text-white text-2xl drop-shadow-lg" />
        </div>
        <div className="absolute bottom-4 left-4">
          <i className="fas fa-chart-line text-white text-2xl drop-shadow-lg" />
        </div>
        <div className="absolute bottom-4 right-4">
          <i className="fab fa-youtube text-white text-3xl drop-shadow-lg" />
        </div>
      </div>
      {/* Course Info */}
      <div className="md:w-2/3 p-6 flex flex-col justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">
            Complete Google NotebookLM Course 2025: Beginner to Pro
          </h2>
          <p className="text-gray-600 mb-3">
            Unlock AI-Powered Research: Practical Guide to Document Analysis &amp; Insights
          </p>
          <p className="text-sm text-gray-700 mb-2">Yash Thakker</p>
          {/* Rating */}
          <div className="flex items-center gap-2 mb-2">
            <span className="text-orange-600 font-bold">4.7</span>
            <div className="flex text-orange-500">
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="fas fa-star-half-alt" />
            </div>
            <span className="text-gray-600 text-sm">(337)</span>
          </div>
          {/* Course Details */}
          <div className="flex flex-wrap gap-2 text-sm text-gray-600">
            <span>1 total hour</span>
            <span>•</span>
            <span>11 lectures</span>
            <span>•</span>
            <span>All Levels</span>
          </div>
        </div>
        {/* Price */}
        <div className="flex items-center justify-end gap-2 mt-4">
          <span className="text-2xl font-bold text-gray-900">₫279,000</span>
          <span className="text-lg text-gray-400 line-through">₫399,000</span>
        </div>
      </div>
    </div>
  </div>
  {/* Course Card 2 */}
  <div className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300 mb-6 overflow-hidden">
    <div className="flex flex-col md:flex-row">
      {/* Course Image */}
      <div className="md:w-1/3 relative">
        <img src="https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=400&h=300&fit=crop" alt="NotebookLM Generative AI" className="w-full h-full object-cover" />
      </div>
      {/* Course Info */}
      <div className="md:w-2/3 p-6 flex flex-col justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">
            NotebookLM : Generative AI Interacting with Your Own Data
          </h2>
          <p className="text-gray-600 mb-3">
            NotebookLM is an interactive AI playground for data analysis and machine learning from the Google Gemini
            team
          </p>
          <p className="text-sm text-gray-700 mb-2">Scott Duffy • 1,000,000+ Students</p>
          {/* Rating */}
          <div className="flex items-center gap-2 mb-2">
            <span className="text-orange-600 font-bold">4.3</span>
            <div className="flex text-orange-500">
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="far fa-star" />
            </div>
            <span className="text-gray-600 text-sm">(337)</span>
          </div>
          {/* Course Details */}
          <div className="flex flex-wrap gap-2 text-sm text-gray-600 mb-3">
            <span>1 total hour</span>
            <span>•</span>
            <span>15 lectures</span>
            <span>•</span>
            <span>Beginner</span>
          </div>
          {/* Bestseller Badge */}
          <span className="inline-block bg-yellow-100 text-yellow-800 text-xs font-semibold px-3 py-1 rounded">
            Bestseller
          </span>
        </div>
        {/* Price */}
        <div className="flex items-center justify-end gap-2 mt-4">
          <span className="text-2xl font-bold text-gray-900">₫279,000</span>
          <span className="text-lg text-gray-400 line-through">₫399,000</span>
        </div>
      </div>
    </div>
  </div>
  {/* Course Card 3 */}
  <div className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300 mb-6 overflow-hidden">
    <div className="flex flex-col md:flex-row">
      {/* Course Image */}
      <div className="md:w-1/3 relative">
        <img src="https://images.unsplash.com/photo-1523961131990-5ea7c61b2107?w=400&h=300&fit=crop" alt="Google NotebookLM Complete Beginners Guide" className="w-full h-full object-cover" />
      </div>
      {/* Course Info */}
      <div className="md:w-2/3 p-6 flex flex-col justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">
            Google NotebookLM: Complete Beginners Guide
          </h2>
          <p className="text-gray-600 mb-3">
            Use artificial intelligence to conduct research and create content
          </p>
          <p className="text-sm text-gray-700 mb-2">Tracey Barron</p>
          {/* Rating */}
          <div className="flex items-center gap-2 mb-2">
            <span className="text-orange-600 font-bold">4.4</span>
            <div className="flex text-orange-500">
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="fas fa-star-half-alt" />
            </div>
            <span className="text-gray-600 text-sm">(273)</span>
          </div>
          {/* Course Details */}
          <div className="flex flex-wrap gap-2 text-sm text-gray-600">
            <span>0.5 total hours</span>
            <span>•</span>
            <span>6 lectures</span>
            <span>•</span>
            <span>Beginner</span>
          </div>
        </div>
        {/* Price */}
        <div className="flex items-center justify-end gap-2 mt-4">
          <span className="text-2xl font-bold text-gray-900">₫279,000</span>
          <span className="text-lg text-gray-400 line-through">₫399,000</span>
        </div>
      </div>
    </div>
  </div>
  {/* Course Card 4 */}
  <div className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300 mb-6 overflow-hidden">
    <div className="flex flex-col md:flex-row">
      {/* Course Image */}
      <div className="md:w-1/3 relative">
        <img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop" alt="NotebookLM Masterclass" className="w-full h-full object-cover" />
      </div>
      {/* Course Info */}
      <div className="md:w-2/3 p-6 flex flex-col justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">
            NotebookLM Masterclass: Transform Your Learning with AI
          </h2>
          <p className="text-gray-600 mb-3">
            Learn NotebookLM From Start To Finish, Use AI To Create Podcasts, Analyze Documents, Manage Notes Easily
            with NotebookLM
          </p>
          <p className="text-sm text-gray-700 mb-2">DFA Course Academy, Krystian Wiśtarewicz</p>
          {/* Rating */}
          <div className="flex items-center gap-2 mb-2">
            <span className="text-orange-600 font-bold">4.1</span>
            <div className="flex text-orange-500">
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="far fa-star" />
            </div>
            <span className="text-gray-600 text-sm">(166)</span>
          </div>
          {/* Course Details */}
          <div className="flex flex-wrap gap-2 text-sm text-gray-600">
            <span>7 total hours</span>
            <span>•</span>
            <span>62 lectures</span>
            <span>•</span>
            <span>All Levels</span>
          </div>
        </div>
        {/* Price */}
        <div className="flex items-center justify-end gap-2 mt-4">
          <span className="text-2xl font-bold text-gray-900">₫279,000</span>
          <span className="text-lg text-gray-400 line-through">₫909,000</span>
        </div>
      </div>
    </div>
  </div>
  {/* Course Card 5 */}
  <div className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300 mb-6 overflow-hidden">
    <div className="flex flex-col md:flex-row">
      {/* Course Image */}
      <div className="md:w-1/3 relative">
        <img src="https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=300&fit=crop" alt="Mastering Google NotebookLM" className="w-full h-full object-cover" />
      </div>
      {/* Course Info */}
      <div className="md:w-2/3 p-6 flex flex-col justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">
            Mastering Google NotebookLM: An AI-Powered Research Tool
          </h2>
          <p className="text-gray-600 mb-3">
            Unlock the Power of AI for Smarter Research, Content Creation, and Productivity with Google NotebookLM
          </p>
          <p className="text-sm text-gray-700 mb-2">Gopaluni Sai Karthik</p>
          {/* Rating */}
          <div className="flex items-center gap-2 mb-2">
            <span className="text-orange-600 font-bold">4.1</span>
            <div className="flex text-orange-500">
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="far fa-star" />
            </div>
            <span className="text-gray-600 text-sm">(134)</span>
          </div>
          {/* Course Details */}
          <div className="flex flex-wrap gap-2 text-sm text-gray-600">
            <span>1 total hour</span>
            <span>•</span>
            <span>11 lectures</span>
            <span>•</span>
            <span>All Levels</span>
          </div>
        </div>
        {/* Price */}
        <div className="flex items-center justify-end gap-2 mt-4">
          <span className="text-2xl font-bold text-gray-900">₫279,000</span>
          <span className="text-lg text-gray-400 line-through">₫399,000</span>
        </div>
      </div>
    </div>
  </div>
  {/* Course Card 6 */}
  <div className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300 mb-6 overflow-hidden">
    <div className="flex flex-col md:flex-row">
      {/* Course Image */}
      <div className="md:w-1/3 relative">
        <img src="https://images.unsplash.com/photo-1531482615713-2afd69097998?w=400&h=300&fit=crop" alt="NotebookLM Mastery" className="w-full h-full object-cover" />
      </div>
      {/* Course Info */}
      <div className="md:w-2/3 p-6 flex flex-col justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">
            NotebookLM Mastery: Organize, Analyze, and Optimize with AI
          </h2>
          <p className="text-gray-600 mb-3">
            Master AI-Powered Research and Productivity with NotebookLM for Smarter Workflows and Better Insights
          </p>
          <p className="text-sm text-gray-700 mb-2">Anton Voroniuk, Anton Voroniuk Support</p>
          {/* Rating */}
          <div className="flex items-center gap-2 mb-2">
            <span className="text-orange-600 font-bold">4.4</span>
            <div className="flex text-orange-500">
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="fas fa-star-half-alt" />
            </div>
            <span className="text-gray-600 text-sm">(120)</span>
          </div>
          {/* Course Details */}
          <div className="flex flex-wrap gap-2 text-sm text-gray-600">
            <span>3.5 total hours</span>
            <span>•</span>
            <span>36 lectures</span>
            <span>•</span>
            <span>All Levels</span>
          </div>
        </div>
        {/* Price */}
        <div className="flex items-center justify-end gap-2 mt-4">
          <span className="text-2xl font-bold text-gray-900">₫279,000</span>
          <span className="text-lg text-gray-400 line-through">₫699,000</span>
        </div>
      </div>
    </div>
  </div>
  {/* Course Card 7 */}
  <div className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300 mb-6 overflow-hidden">
    <div className="flex flex-col md:flex-row">
      {/* Course Image */}
      <div className="md:w-1/3 relative">
        <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=400&h=300&fit=crop" alt="Google NotebookLM" className="w-full h-full object-cover" />
      </div>
      {/* Course Info */}
      <div className="md:w-2/3 p-6 flex flex-col justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">
            Google NotebookLM
          </h2>
          <p className="text-gray-600 mb-3">
            Master Google NotebookLM: AI-Powered Research, Productivity Enhancement &amp; Real-World Applications
          </p>
          <p className="text-sm text-gray-700 mb-2">Start-Tech Academy</p>
          {/* Rating */}
          <div className="flex items-center gap-2 mb-2">
            <span className="text-orange-600 font-bold">4.5</span>
            <div className="flex text-orange-500">
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="fas fa-star" />
              <i className="fas fa-star-half-alt" />
            </div>
            <span className="text-gray-600 text-sm">(104)</span>
          </div>
          {/* Course Details */}
          <div className="flex flex-wrap gap-2 text-sm text-gray-600">
            <span>1 total hour</span>
            <span>•</span>
            <span>12 lectures</span>
            <span>•</span>
            <span>All Levels</span>
          </div>
        </div>
        {/* Price */}
        <div className="flex items-center justify-end gap-2 mt-4">
          <span className="text-2xl font-bold text-gray-900">₫279,000</span>
          <span className="text-lg text-gray-400 line-through">₫399,000</span>
        </div>
      </div>
    </div>
  </div>
</div>
   
  );
}
