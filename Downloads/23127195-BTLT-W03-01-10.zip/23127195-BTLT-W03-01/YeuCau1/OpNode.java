public class OpNode{
    private String operator;
    private Object leftNode;
    private Object rightNode;
    public OpNode(String operator)
    {
        this.operator=operator;
        this.leftNode=null;
        this.rightNode=null;
    }
    public void addLeft(Object node)
    {
        this.leftNode=node;
    }
    public void addRight(Object node)
    {
        this.rightNode=node;
    }
    public double evaluate()
    {
        double leftValue=evaluateNode(leftNode);
        double rightValue=evaluateNode(rightNode);
        switch(operator)
        {
            case "+":
                return leftValue + rightValue;
            case "-":
                return leftValue - rightValue;
            case "*":
                return leftValue * rightValue;
            case "/":
                return leftValue / rightValue;
            default:
                throw new UnsupportedOperationException("Unknown operator: " + operator);
        }
    }
    public double evaluateNode(Object node)
    {
        if (node instanceof NumNode)
        {
            return ((NumNode) node).evaluate();
        }
        else if (node instanceof OpNode)
        {
            return ((OpNode) node).evaluate();
        }
        else
        {
            throw new IllegalArgumentException("Invalid node type");
        }
    }
    @Override
    public String toString()
    {
        return "(" + leftNode + " " + operator + " " + rightNode + ")";
    }
}