public class NumNode {
    private double value;
    
    public NumNode(double value) {
        this.value = value;
    }
    

    public double evaluate() {
        return value;
    }
    

    public double getValue() {
        return value;
    }
  
    public void setValue(double value) {
        this.value = value;
    }
    
    @Override
    public String toString() {
        return String.valueOf(value);
    }
}
