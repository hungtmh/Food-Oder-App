
public class Main {
    
    public static void main(String[] args) {
        System.out.println("=== Expression Tree Evaluation Demo ===\n");
        
 
        System.out.println("Example 1: 2 + 3");
        OpNode n = new OpNode("+");
        NumNode two = new NumNode(2);
        NumNode three = new NumNode(3);
        n.addLeft(two);
        n.addRight(three);
        double x = n.evaluate();
        System.out.println("Expression: " + n);
        System.out.println("Result: " + x);
        System.out.println("Expected: 5.0");
        System.out.println();
        
        // Example 2: 2 * (3 + 4)
        System.out.println("Example 2: 2 * (3 + 4)");
        OpNode n1 = new OpNode("+");
        n1.addLeft(new NumNode(3));
        n1.addRight(new NumNode(4));
        
        OpNode n2 = new OpNode("*");
        n2.addLeft(new NumNode(2));
        n2.addRight(n1);
        
        double y = n2.evaluate();
        System.out.println("Expression: " + n2);
        System.out.println("Result: " + y);
        System.out.println("Expected: 14.0");
        System.out.println();
        
     
        System.out.println("Example 3: (5 - 2) * (8 / 4)");
        OpNode subtraction = new OpNode("-");
        subtraction.addLeft(new NumNode(5));
        subtraction.addRight(new NumNode(2));
        
        OpNode division = new OpNode("/");
        division.addLeft(new NumNode(8));
        division.addRight(new NumNode(4));
        
        OpNode multiplication = new OpNode("*");
        multiplication.addLeft(subtraction);
        multiplication.addRight(division);
        
        double z = multiplication.evaluate();
        System.out.println("Expression: " + multiplication);
        System.out.println("Result: " + z);
        System.out.println("Expected: 6.0");
        System.out.println();
        
       
        System.out.println("Example 4: ((10 / 2) + (3 * 4)) - 1");
        OpNode div = new OpNode("/");
        div.addLeft(new NumNode(10));
        div.addRight(new NumNode(2));
        
        OpNode mult = new OpNode("*");
        mult.addLeft(new NumNode(3));
        mult.addRight(new NumNode(4));
        
        OpNode add = new OpNode("+");
        add.addLeft(div);
        add.addRight(mult);
        
        OpNode sub = new OpNode("-");
        sub.addLeft(add);
        sub.addRight(new NumNode(1));
        
        double w = sub.evaluate();
        System.out.println("Expression: " + sub);
        System.out.println("Result: " + w);
        System.out.println("Expected: 16.0");
        System.out.println();
        
    }
}
